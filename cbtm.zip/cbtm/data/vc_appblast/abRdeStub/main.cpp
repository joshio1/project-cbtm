/* **************************************************************************
 * Copyright (C) 2014 VMware, Inc. All Rights Reserved -- VMware Confidential
 * **************************************************************************/

/*
 * main.cpp --
 *
 *    Blast Rde Server Stub DLL.
 *
 *    Starts RdeServer process in the blast app session.
 */

#include <windows.h>
#include <stdio.h>
#include "Logging.h"
#include "vvc.h"

#define RDE_SRV_KEY L"SOFTWARE\\VMware, Inc.\\VMware Blast\\vvc\\Plugins\\blastRdeStub"
#define DEFINE_LOGGER log4cxx::LoggerPtr LOG = log4cxx::Logger::getLogger("BlastRdeStub")

static VvcListenerHandle sVvcListener = NULL;
static VvcIntfV12 sVvcIntfV12 = { 0 };
wchar_t sRdePath[1024] = { 0 };

/*
 *----------------------------------------------------------------------
 *
 *  DllMain --
 *
 *    Main Dll entry.
 *
 * Results:
 *    TRUE if successful or FALSE otherwise.
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */

BOOL WINAPI
DllMain(HMODULE hModule,           // IN
        DWORD  ul_reason_for_call, // IN
        LPVOID lpReserved)         // IN
{
   switch (ul_reason_for_call) {
   case DLL_PROCESS_ATTACH:
      break;
   case DLL_PROCESS_DETACH:
      break;
   case DLL_THREAD_ATTACH:
      break;
   case DLL_THREAD_DETACH:
      break;
   }
   return TRUE;
}


/*
 *----------------------------------------------------------------------
 *
 *  StartRdeServer --
 *
 *    Launch the RdeServer process.
 *
 * Results:
 *    TRUE if successful or FALSE otherwise.
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */

BOOL
StartRdeServer(void)
{
   DEFINE_LOGGER;

   wchar_t cmdline[1024]= { 0 };
   PROCESS_INFORMATION pi = { 0 };
   STARTUPINFO si = { 0 };

   DWORD pid = GetCurrentProcessId();
   swprintf_s(cmdline, ARRAYSIZE(cmdline), L"\"%s\" -p %d", sRdePath, pid);

   si.cb = sizeof(si);

   if (!CreateProcessW(NULL, cmdline, NULL, NULL, FALSE,
                       DETACHED_PROCESS, NULL, NULL, &si, &pi)) {
      LOG_ERROR(LOG, "Failed to start rde server process, error:0x%08lx.",
                GetLastError());
      return FALSE;
   }

   LOG_INFO(LOG, "RdeServer process started.");
   return TRUE;
}


/*
 *----------------------------------------------------------------------
 *
 *  RdeServerThreadFunc --
 *
 *    Helper thread routine to start RdeServer in separate thread.
 *
 * Results:
 *    Always 0.
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */

DWORD WINAPI
RdeServerThreadFunc(void *data) // IN
{
   StartRdeServer();
   return 0;
}


/*
 *----------------------------------------------------------------------------
 *
 * vvcOnListenerConnect --
 *
 *      Callback when listener has detected a connect event.
 *      Creates helper thread for starting rde server process.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void
vvcOnListenerConnect(char *name,                 // IN
                     VvcListenerHandle listener, // IN
                     void *connCookie,           // IN
                     uint32 connCaps,            // IN
                     int32 sessId,               // IN
                     void *clientData)           // IN
{
   DEFINE_LOGGER;
   LOG_INFO(LOG, "vvcOnListenerConnect called");

   HANDLE hThread = CreateThread(NULL, 0, RdeServerThreadFunc, 0, 0, 0);
   CloseHandle(hThread);
}


/*
 *----------------------------------------------------------------------------
 *
 * vvcOnListenerDisconnect --
 *
 *      Callback when listener has detected a disconnect event.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void
vvcOnListenerDisconnect(VvcListenerHandle listener, // IN
                        int32 sessId,               // IN
                        void *clientData)           // IN
{
   DEFINE_LOGGER;
   LOG_INFO(LOG, "vvcOnListenerDisconnect called");

   // Do nothing to stop rde server. It will exit by itself
   // on vdpservice disconnect event.
}


/*
 *----------------------------------------------------------------------------
 *
 * vvcOnListenerClose --
 *
 *      Callback when listener has detected a close event.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void
vvcOnListenerClose(VvcListenerHandle listener, // IN
                   void *clientData)           // IN
{
   DEFINE_LOGGER;
   LOG_INFO(LOG, "vvcOnListenerClose called");
}


/*
 *----------------------------------------------------------------------------
 *
 * vvcOnListenerPeerOpen --
 *
 *      Callback when listener has detected a peer open event.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void
vvcOnListenerPeerOpen(char *name,                 // IN
                      VvcListenerHandle listener, // IN
                      void *connCookie,           // IN
                      uint32 connCaps,
                      int32 sessId,
                      uint8 *initData,
                      size_t initDataLen,
                      void *clientData)
{
   DEFINE_LOGGER;
   LOG_INFO(LOG, "vvcOnListenerPeerOpen called");
}


/*
 *----------------------------------------------------------------------
 *
 *  VVC_Start --
 *
 *    Init entry for plugin dll.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
VvcStatus __cdecl
VVC_Start(VvcIntfVer    *maxSupportedVer, // IN
          VVCFN_GetIntf getIntfFn,        // IN
          uint32        reserved,         // IN
          void**        clientData)       // OUT
{
   DEFINE_LOGGER;

   VvcStatus status;
   VvcIntfVer reqdVersion;
   int sessionId;
   char channel[256] = { 0 };

   if (wcslen(sRdePath) == 0) {
      HKEY hkey = NULL;
      if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, RDE_SRV_KEY, 0,
                        KEY_QUERY_VALUE, &hkey) != ERROR_SUCCESS) {
         LOG_ERROR(LOG, "Failed to open blast rde server path registry key.");
         return VVC_STATUS_ERROR;
      }

      DWORD pathSize = sizeof(sRdePath);
      if (RegQueryValueExW(hkey, L"rdepath", 0, NULL,
                           (LPBYTE)sRdePath, &pathSize) != ERROR_SUCCESS) {
         LOG_ERROR(LOG, "Failed to read blast rde server path from the registry.");
         RegCloseKey(hkey);
         return VVC_STATUS_ERROR;
      }

      RegCloseKey(hkey);
   }

   reqdVersion.major = VVC_MAJOR_VER_1;
   reqdVersion.minor = VVC_MINOR_VER_2;

   sVvcIntfV12.size = sizeof(sVvcIntfV12);

   status = getIntfFn(&reqdVersion, &sVvcIntfV12);
   if (!VVC_SUCCESS(status)) {
      LOG_ERROR(LOG, "Failed to get vvc lib func table, status: %d", status);
      return status;
   }

   // Create a VVC Listener
   VvcListenerEvents listenerEvents = { 0 };
   listenerEvents.onConnect = vvcOnListenerConnect;
   listenerEvents.onDisconnect = vvcOnListenerDisconnect;
   listenerEvents.onPeerOpen = vvcOnListenerPeerOpen;
   listenerEvents.onClose = vvcOnListenerClose;

   sVvcIntfV12.getCurrentProcessSessionId(&sessionId);
   sprintf_s(channel, sizeof(channel), "rdeVvcStub-%d", GetCurrentProcessId());

   status = sVvcIntfV12.createListener(sessionId,
                                       channel,
                                       &listenerEvents,
                                       NULL,
                                       &sVvcListener);
   if (!VVC_SUCCESS(status)) {
      LOG_ERROR(LOG, "Failed to create VVC listener, status: %d", status);
      return status;
   }

   status = sVvcIntfV12.activateListener(sVvcListener);
   if (!VVC_SUCCESS(status)) {
      LOG_ERROR(LOG, "Failed to activate VVC listener, status: %d", status);
      sVvcIntfV12.closeListener(sVvcListener);
      sVvcListener = NULL;
      return status;
   }

   LOG_INFO(LOG, "Created VVC listener for 'rdeVvcStub'");

   return status;
}


/*
 *----------------------------------------------------------------------
 *
 *  VVC_Stop --
 *
 *    Exit entry for plugin dll.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
void __cdecl
VVC_Stop(uint32 reserved,   // IN
         void*  clientData) // IN
{
   DEFINE_LOGGER;

   if (sVvcListener) {
      LOG_INFO(LOG, "Closed VVC listener: %p", sVvcListener);

      sVvcIntfV12.closeListener(sVvcListener);
      sVvcListener = NULL;
   }
}