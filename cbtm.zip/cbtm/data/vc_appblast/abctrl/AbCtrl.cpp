/* **********************************************************
 * Copyright (C) 2012, 2014-2017 Vmware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

/*
 * abctrl.cpp --
 *
 *    AppBlast Controller DLL
 */

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <sstream>
#include <iostream>

#include "IAbCtrl.h"
#include "PipeSecurity.h"
#include "PipeServer.h"
#include "PipeClient.h"
#include "PipeCommon.h"
#include "PipeDefs.h"   // for PIPE_REPLY_NOT_OK

#define SERVICE_NAME L"VMBlast"

/* Strings used to build fancy function-name labels for log messages. */
#define LOGLABEL_PREFIX  "AbCtrl/"
#define LOGLABEL_SUFFIX  ": "
#define LOGLABEL(fmt)   (LOGLABEL_PREFIX __FUNCTION__ LOGLABEL_SUFFIX fmt)

/* In the MS Visual Studio compiler __FUNCTION__ is replaced by a string literal
 * which can be pasted together with other string literals at compile time, as
 * in the LOGLABEL macro above.
 *
 * In other compilers __FUNCTION__ (or __func__ or whatever magic name is used
 * to get the name of the current function) might be a pointer-to-char variable
 * rather than a literal string.  In that case the string-pasting LOGLABEL macro
 * above will fail.  For those compilers you can use this LOGLABEL definition
 * instead:
 *
 * #define LOGLABEL(fmt) (LOGLABEL_PREFIX "%s" LOGLABEL_SUFFIX fmt), (__FUNCTION__)
 *
 * This definition will work for both variables and literal strings but it has
 * the downside of doing more work at runtime than the string-pasting approach,
 * which does its work at compile time.
 */


// See IAbCtrl.h for callbacks about session changes

/* Static functions */
static DWORD
InitializeDll(bool securePipes);

static void
InitializeLogging();

static std::string
HandleEventMessage(const std::string& msg);

static wchar_t*
GetDebugLogName();

static void
Log(const char *format, ...);

static void
LogV(const char *format, va_list vargs);

/* Forward declarations */
DWORD AbCtrlStructSize(uint64 version, size_t *size);

class EventPipeServerHelper;

/* Globals */
static SessionConnectCb           gConnectCb = NULL;
static SessionConnectCbV2         gConnectCbV2 = NULL;
static HANDLE                     gLogFileH = INVALID_HANDLE_VALUE;
static EventPipeServerHelper*     gEventPipeHelper = NULL;
static pipelib::PipeSecurityAttr* gEventPipeSA = NULL;
static pipelib::PipeServer*       gEventPipeServer = NULL;
static pipelib::PipeClient*       gRequestPipeClient = NULL;


/*
 * -----------------------------------------------------------------------------
 * class EventPipeServerHelper --
 *
 *    An event pipe server needs a helper class to control thread execution and
 *    to handle client requests. This class performs those for our pipe server,
 *    which accepts session events from AppBlast.
 *
 * -----------------------------------------------------------------------------
 */

class EventPipeServerHelper : public pipelib::PipeServerHelper
{
public:
   EventPipeServerHelper() { }
   virtual ~EventPipeServerHelper() { };

   virtual std::string HandleStringMessage(const std::string& msg) {
      if (msg.empty()) {
         return "";
      }

      // Parse the message (some event command and some data)
      std::string cmd, data;
      std::stringstream ss(msg);
      ss >> cmd;
      ss >> data;

      const char * const cmdString = pipelib::GetCommandString(cmd);
      Log(LOGLABEL("Received command:%s from service."), cmdString);

      if (cmd == pipelib::ABIPC_SESSION_CREATE_MSG) {
         // A new session - fire the application's callback
         if (gConnectCbV2) {
            // The SESSION_CREATED callback does not use the "reason" argument.
            (*gConnectCbV2)(TRUE, data.c_str(), VDPCONNECT_INVALID);
         } else {
            (*gConnectCb)(TRUE, data.c_str());
         }
      } else if (cmd == pipelib::ABIPC_SESSION_DELETE_MSG) {
         // A deleted session - fire the application's callback
         int reason = VDPCONNECT_INVALID;
         ss >> reason;
         if (reason == VDPCONNECT_INVALID) {
            Log(LOGLABEL("ERROR: Invalid reason code (reason:%d)."), reason);
         } else {
            Log(LOGLABEL("Reason:%d."), reason);
         }

         if (gConnectCbV2) {
            (*gConnectCbV2)(FALSE, data.c_str(), (VDPConnectionResult) reason);
         } else if (gConnectCb) {
            Log(LOGLABEL("Reason is not used due to older callback version."));
            (*gConnectCb)(FALSE, data.c_str());
         }
      }

      // Any reply will suffice
      return "OK";
   }

   virtual void Log(const char *fmt, ...) {
      va_list args;
      va_start(args, fmt);
      ::LogV(fmt, args);
      va_end(args);
   }
};


/*
 *------------------------------------------------------------------------------
 * AbCtrl_Initialize() --
 *
 *    One-time initialization function for the DLL. Called when the DLL is first
 *    loaded into a process. Match this with a call to AbCtrl_Cleanup(), no
 *    matter if this function succeeds or fails.
 *
 * Results:
 *    ERROR_SUCCESS if initialization was successful. If the named pipe server
 *    could not be created, ERROR_ACCESS_DENIED is returned.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AbCtrl_Initialize()
{
   return InitializeDll(true);
}


#ifdef DEVELOPER_FRIENDLY
/*
 *------------------------------------------------------------------------------
 * AbCtrl_InitializeTest() --
 *
 *    One-time initialization function for the DLL. Called when the DLL is first
 *    loaded into a process. Match this with a call to AbCtrl_Cleanup(), no
 *    matter if this function succeeds or fails. THIS FUNCTION IS FOR INTERNAL
 *    USE ONLY: IT CREATES THE PIPE WITHOUT SECURITY RESTRICTIONS.
 *
 * Results:
 *    ERROR_SUCCESS if initialization was successful. If the named pipe server
 *    could not be created, ERROR_ACCESS_DENIED is returned.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AbCtrl_InitializeTest()
{
   return InitializeDll(false);
}
#endif


/*
 *------------------------------------------------------------------------------
 * AbCtrl_Cleanup() --
 *
 *    One-time clean-up function for the DLL. Called when the DLL is unloaded
 *    from a process. Match a call to AbCtrl_Initialize() with this.
 *
 * Results:
 *    Always ERROR_SUCCESS.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AbCtrl_Cleanup()
{
   if (gEventPipeServer) {
      gEventPipeServer->Stop();
   }

   if (gLogFileH != INVALID_HANDLE_VALUE) {
      FlushFileBuffers(gLogFileH);
      CloseHandle(gLogFileH);
      gLogFileH = INVALID_HANDLE_VALUE;
   }

   delete gEventPipeServer;
   gEventPipeServer = NULL;

   delete gEventPipeHelper;
   gEventPipeHelper = NULL;

   delete gRequestPipeClient;
   gRequestPipeClient = NULL;

   delete gEventPipeSA;
   gEventPipeSA = NULL;

   return ERROR_SUCCESS;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_IsRunning() --
 *
 *    Check if AppBlast is running. If the service is not installed or cannot
 *    be queried, an error is returned. Otherwise, ERROR_SUCCESS is returned
 *    and the argument 'isRunning' will be set to 'true' or 'false'.
 *
 * Results:
 *    ERROR_SUCCESS and sets isRunning to true or false; else an error.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_IsRunning(bool* isRunning) // OUT
{
   if (!isRunning) {
      Log(LOGLABEL("ERROR: Invalid empty argument, isRunning:NULL."));
      return ERROR_BAD_ARGUMENTS;
   }

   DWORD result = ERROR_SUCCESS;
   SC_HANDLE managerH = NULL;
   SC_HANDLE serviceH = NULL;

   managerH = OpenSCManager(NULL, NULL,
                            SC_MANAGER_CONNECT |
                            SC_MANAGER_ENUMERATE_SERVICE);
   if (!managerH) {
      result = GetLastError();
      Log(LOGLABEL("ERROR: OpenSCManager failed, error:0x%08lx."), result);
      goto out;
   }

   serviceH = OpenService(managerH,
                         SERVICE_NAME,
                         SERVICE_START | SERVICE_STOP |
                         SERVICE_QUERY_CONFIG | SERVICE_QUERY_STATUS);
   if (!serviceH) {
      result = GetLastError();
      Log(LOGLABEL("ERROR: OpenService failed, error:0x%08lx."), result);
      goto out;
   }

   SERVICE_STATUS status;
   if (!QueryServiceStatus(serviceH, &status)) {
      result = GetLastError();
      Log(LOGLABEL("ERROR: QueryServiceStatus failed, error:0x%08lx."),
          result);
      goto out;
   }

   *isRunning = (status.dwCurrentState == SERVICE_RUNNING);
   Log(LOGLABEL("isRunning:%s."), *isRunning ? "true" : "false");

out:
   if (serviceH) {
      CloseServiceHandle(serviceH);
   }
   if (managerH) {
      CloseServiceHandle(managerH);
   }

   return result;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_IsInstalled() --
 *
 *    Check if AppBlast is installed.
 *
 * Results:
 *    If successful, returns ERROR_SUCCESS and sets 'isInstalled' to either true
 *    or false. On error, returns an error code.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_IsInstalled(bool* isInstalled)      // OUT
{
   if (!isInstalled) {
      Log(LOGLABEL("ERROR: Invalid empty argument, isInstalled:NULL."));
      return ERROR_BAD_ARGUMENTS;
   }

   /*
    * Rely on the returned value of _IsRunning to indicate service installation
    * status.
    */
   bool isRunning;
   DWORD err = AppBlast_IsRunning(&isRunning);

   if (err == ERROR_SUCCESS) {
      /* Service installed */
      *isInstalled = true;
   } else if (err == ERROR_SERVICE_DOES_NOT_EXIST) {
      /* Service not installed */
      err = ERROR_SUCCESS;
      *isInstalled = false;
   }

   Log(LOGLABEL("isInstalled:%s, error:0x%08lx."),
       *isInstalled ? "true" : "false", err);
   return err;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_Start() --
 *
 *    Starts the AppBlast service. On success, or if already started, returns
 *    ERROR_SUCCESS, else returns an error code.
 *
 * Results:
 *    See above.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_Start()
{
   DWORD result = ERROR_SUCCESS;
   SC_HANDLE managerH = NULL;
   SC_HANDLE serviceH = NULL;

   /* Short circuit if already running */
   bool running;
   result = AppBlast_IsRunning(&running);
   if (result == ERROR_SUCCESS && running) {
      Log(LOGLABEL("Service is already running."));
      return ERROR_SUCCESS;
   }

   managerH = OpenSCManager(NULL, NULL,
                            SC_MANAGER_CONNECT |
                            SC_MANAGER_ENUMERATE_SERVICE);
   if (!managerH) {
      result = GetLastError();
      Log(LOGLABEL("ERROR: OpenSCManager failed, error:0x%08lx."), result);
      goto out;
   }

   serviceH = OpenService(managerH,
                          SERVICE_NAME,
                          SERVICE_START | SERVICE_STOP |
                          SERVICE_QUERY_CONFIG | SERVICE_QUERY_STATUS);
   if (!serviceH) {
      result = GetLastError();
      Log(LOGLABEL("ERROR: OpenService failed, error:0x%08lx."), result);
      goto out;
   }

   if (!StartService(serviceH, 0, NULL)) {
      result = GetLastError();
      if (result == ERROR_SERVICE_ALREADY_RUNNING) {
         Log(LOGLABEL("ERROR: StartService failed since service is already "
                      "running."));
         result = ERROR_SUCCESS;
      } else {
         Log(LOGLABEL("ERROR: StartService failed, error:0x%08lx."), result);
         goto out;
      }
   }

   Log(LOGLABEL("Service started successfully."));

out:
   if (serviceH) {
      CloseServiceHandle(serviceH);
   }
   if (managerH) {
      CloseServiceHandle(managerH);
   }
   return result;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_Stop() --
 *
 *    Stops the AppBlast service. On success, or if already stopped, returns
 *    ERROR_SUCCESS, else returns an error code.
 *
 * Results:
 *    See above.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_Stop()
{
   DWORD result = ERROR_SUCCESS;
   SC_HANDLE managerH = NULL;
   SC_HANDLE serviceH = NULL;

   /* Short circuit if already stopped. */
   bool running;
   result = AppBlast_IsRunning(&running);
   if (result == ERROR_SUCCESS && !running) {
      Log(LOGLABEL("Service is already stopped."));
      return ERROR_SUCCESS;
   }

   managerH = OpenSCManager(NULL, NULL,
                            SC_MANAGER_CONNECT |
                            SC_MANAGER_ENUMERATE_SERVICE);
   if (!managerH) {
      result = GetLastError();
      Log(LOGLABEL("ERROR: OpenSCManager failed, error:0x%08lx."), result);
      goto out;
   }

   serviceH = OpenService(managerH,
                         SERVICE_NAME,
                         SERVICE_START | SERVICE_STOP |
                         SERVICE_QUERY_CONFIG | SERVICE_QUERY_STATUS);
   if (!serviceH) {
      result = GetLastError();
      Log(LOGLABEL("ERROR: OpenService failed, error:0x%08lx."), result);
      goto out;
   }

   SERVICE_STATUS status;
   if (!ControlService(serviceH, SERVICE_CONTROL_STOP, &status)) {
      result = GetLastError();
      Log(LOGLABEL("ERROR: ControlService failed, error:0x%08lx."), result);
      goto out;
   }

   Log(LOGLABEL("Service stopped successfully."));

out:
   if (serviceH) {
      CloseServiceHandle(serviceH);
   }
   if (managerH) {
      CloseServiceHandle(managerH);
   }

   return result;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_IsInUse() --
 *
 *    Determine whether there is at least one active AppBlast session running at
 *    the current time. AppBlast is queried for the number of sessions,
 *    and if greater than zero, 'isInUse' is set to true; if zero, false.
 *
 * Results:
 *    ERROR_SUCCESS and sets isInUse to true or false; else an error.
 *
 * Side effects:
 *    Queries AppBlast using IPC call.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_IsInUse(bool* isInUse)   // OUT
{
   if (!isInUse) {
      Log(LOGLABEL("ERROR: Invalid empty argument, isInUse:NULL."));
      return ERROR_BAD_ARGUMENTS;
   }

   std::string cmd = pipelib::ABIPC_SESSION_COUNT_MSG;
   const char * const cmdString = pipelib::GetCommandString(cmd);
   Log(LOGLABEL("Sending command:%s"), cmdString);

   std::string response;
   DWORD result = gRequestPipeClient->SendStringMessage(cmd, response);
   if (result == ERROR_SUCCESS) {
      Log(LOGLABEL("Received response:'%s'"), response.c_str());
      int sessionCount = atoi(response.c_str());
      *isInUse = (sessionCount > 0);
   } else {
      Log(LOGLABEL("ERROR: Failed sending command:%s to service, "
                   "error:0x%08lx."),
          cmdString, result);
   }

   return result;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_GetIpAndPort() --
 *
 *    Get the IP address and port number that AppBlast is listening to. Caller
 *    can request either the unsecure or secure port.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS and sets 'portPtr' to a valid port
 *    number (non-zero) and fills 'ipBuffer' with the IP address. On failure,
 *    returns an error code and leaves arguments untouched.
 *
 * Side effects:
 *    Queries AppBlast using IPC call.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_GetIpAndPort(bool secureMode,        // IN
                      char *ipBuffer,         // IN/OUT
                      size_t ipBufferLen,     // IN
                      int *portPtr)           // OUT
{
   if (!ipBuffer || !portPtr) {
      Log(LOGLABEL("ERROR: Invalid empty argument, ipBuffer:%p, portPtr:%p."),
          ipBuffer, portPtr);
      return ERROR_BAD_ARGUMENTS;
   }

   std::string cmd = pipelib::ABIPC_IP_PORT_MSG;
   const char * const cmdString = pipelib::GetCommandString(cmd);
   Log(LOGLABEL("Sending command:%s"), cmdString);

   std::string response;
   DWORD result = gRequestPipeClient->SendStringMessage(cmd, response);
   if (ERROR_SUCCESS != result) {
      Log(LOGLABEL("Failed sending command:%s to service, error:0x%08lx."),
          cmdString, result);
   } else {
      Log(LOGLABEL("Received response:'%s'"), response.c_str());

      // Parse three words (IP, port, secure port) from response
      std::stringstream ss(response);
      std::string ip, port, sport;
      ss >> ip;
      ss >> port;
      ss >> sport;

      if (ip.empty() || port.empty() || sport.empty()) {
         result = ERROR_INVALID_DATA;
      } else {
         int portVal = atoi(secureMode ? sport.c_str() : port.c_str());
         if (0 >= portVal) {
            result = ERROR_INVALID_DATA;
         } else {
            result = strncpy_s(ipBuffer, ipBufferLen, ip.c_str(), _TRUNCATE);
            if (ERROR_SUCCESS != result) {
               Log(LOGLABEL("ERROR: Response copy failed for IP, "
                            "error:0x%08lx."),
                   result);
            } else {
               *portPtr = portVal;
            }
         }
      }
   }

   return result;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_GetStatus() --
 *
 *    Query AppBlast to determine what the status is.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS. Else, return a suitable error.
 *
 * Side effects:
 *    Queries AppBlast using IPC call.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_GetStatus() // IN
{
   std::string cmd = pipelib::ABIPC_GET_STATUS_MSG;
   const char * const cmdString = pipelib::GetCommandString(cmd);
   Log(LOGLABEL("Sending command:%s"), cmdString);

   std::string response;
   DWORD result = gRequestPipeClient->SendStringMessage(cmd, response);
   if (result == ERROR_SUCCESS) {
      Log(LOGLABEL("Received response:'%s'"), response.c_str());
   } else {
      Log(LOGLABEL("ERROR: Failed sending command:%s to service, "
                   "error:0x%08lx."),
          cmdString, result);
   }

   return result;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_SetConnectCallback() --
 *
 *    Set a callback function which will be invoked whenever the AppBlast
 *    session count changes. The callback will be passed the current session
 *    count. Only one callback can be set at a time. To remove the callback,
 *    pass NULL.
 *
 * Results:
 *    If set, returns ERROR_SUCCESS. If the event listening thread was not
 *    created, this callback won't work, so either ERROR_INVALID_HANDLE or some
 *    other error code will be returned in that case.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_SetConnectCallback(SessionConnectCb callback)   // IN
{
   gConnectCb = callback;
   return ERROR_SUCCESS;
}


extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_SetConnectCallbackV2(SessionConnectCbV2 callback)   // IN
{
   gConnectCbV2 = callback;
   return ERROR_SUCCESS;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_PrepareSessionEx() --
 *
 *    Tell AppBlast to generate a new session token, and accept it as valid
 *    when received. The session token that AppBlast generates is returned in
 *    the output argument 'tokenPtr', which is space allocated by the caller.
 *    Also, get the IP address and port number that AppBlast is listening to.
 *    Caller can request either the unsecure or secure port.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS, fills 'tokenPtr' with a new and
 *    unique session token, sets 'portPtr' to a valid port number (non-zero)
 *    and fills 'ipBuffer' with the IP address. On failure, returns an error code.
 *
 * Side Effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_PrepareSessionEx(DWORD sessionId,         // IN
                          bool secureMode,         // IN
                          char* tokenPtr,          // IN/OUT
                          size_t maxTokenLen,      // IN
                          char* ipBuffer,          // IN/OUT
                          size_t ipBufferLen,      // IN
                          int* portPtr)            // IN/OUT
{
   DWORD result = ERROR_SUCCESS;

   if (ipBuffer != NULL && portPtr != NULL) {
      Log(LOGLABEL("Find IP, Port for SessionID:%lu."), sessionId);
      result = AppBlast_GetIpAndPort(secureMode,
                                     ipBuffer,
                                     ipBufferLen,
                                     portPtr);
      if (result != ERROR_SUCCESS) {
         Log(LOGLABEL("ERROR: Could not get the IP and Port, error:0x%08lx."),
             result);
         return result;
      }
   }

   if (!tokenPtr) {
      Log(LOGLABEL("ERROR: Invalid empty argument, tokenPtr:NULL."));
      return ERROR_BAD_ARGUMENTS;
   }

   std::string cmd = pipelib::ABIPC_NEW_TOKEN_MSG;
   const char * const cmdString = pipelib::GetCommandString(cmd);
   Log(LOGLABEL("Sending command:%s"), cmdString);

   /*
    * ip and port pointers are NULL in the legacy case, where we have
    * no valid sessionId passed in
    */
   if (ipBuffer != NULL && portPtr != NULL) {
      cmd += pipelib::ABIPC_MSG_DELIM;
      std::stringstream ss;
      ss << sessionId;
      cmd += ss.str();
   }

   std::string response;
   result = gRequestPipeClient->SendStringMessage(cmd, response);
   if (ERROR_SUCCESS != result) {
      Log(LOGLABEL("Failed sending command:%s to service, error:0x%08lx."),
          cmdString, result);
   } else {
      Log(LOGLABEL("Received response:*****"));
      result = strncpy_s(tokenPtr, maxTokenLen, response.c_str(), _TRUNCATE);
      if (ERROR_SUCCESS != result) {
         Log(LOGLABEL("ERROR: Response copy failed for token, error:0x%08lx."),
             result);
      }
   }
   return result;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_PrepareSession() --
 *
 *    Tell AppBlast to generate a new session token, and accept it as valid
 *    when received. The session token that AppBlast generates is returned in
 *    the output argument 'tokenPtr', which is space allocated by the caller.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS and fills 'tokenPtr' with a new and
 *    unique session token. On failure, returns an error code.
 *
 * Side Effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_PrepareSession(char* tokenPtr,      // OUT
                        size_t maxTokenLen)  // IN
{
   return AppBlast_PrepareSessionEx(0,
                                    true,
                                    tokenPtr,
                                    maxTokenLen,
                                    NULL,
                                    0,
                                    NULL);
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_PrepareSessionHelper() --
 * AppBlast_ShadowPrepareSession() --
 * AppBlast_PrepareSession2() --
 *
 *    Tell AppBlast to generate a new session token, and accept it as valid
 *    when received. The session token that AppBlast generates is returned in
 *    the output argument 'tokenPtr', which is space allocated by the caller.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS and fills 'tokenPtr' with a new and
 *    unique session token. On failure, returns an error code.
 *
 * Side Effects:
 *    The appblast service will bind to the address specified if it has not
 *    already been bound.
 *
 *------------------------------------------------------------------------------
 */

DWORD
AppBlast_PrepareSessionHelper(std::string cmd,       // IN
                              DWORD sessionId,       // IN
                              char *tokenPtr,        // OUT
                              size_t maxTokenLen,    // IN
                              const char *addrIPv4,  // IN
                              const char *addrIPv6,  // IN
                              int *portPtr,          // IN/OUT
                              bool allowInput)       // IN
{
   std::string response, token;
   std::ostringstream out;
   DWORD result;
   int port = 0;

   if (!tokenPtr || !portPtr || (!addrIPv4 && !addrIPv6)) {
      Log(LOGLABEL("ERROR: Invalid empty argument, tokenPtr:%p, portPtr:%p, "
                   "addrIPv4:%p, addrIPv6:%p."),
          tokenPtr, portPtr, addrIPv4, addrIPv6);
      return ERROR_BAD_ARGUMENTS;
   }

   const char * const cmdString = pipelib::GetCommandString(cmd);
   Log(LOGLABEL("Sending command:%s"), cmdString);

   // Send PrepareSession message
   out << cmd
       << pipelib::ABIPC_MSG_DELIM
       << sessionId
       << pipelib::ABIPC_MSG_DELIM
       << *portPtr
       << pipelib::ABIPC_MSG_DELIM
       << allowInput ? "1" : "0";;

   if (addrIPv4) {
      out << pipelib::ABIPC_MSG_DELIM
          << addrIPv4;
   }

   if (addrIPv6) {
      out << pipelib::ABIPC_MSG_DELIM
          << addrIPv6;
   }

   result = gRequestPipeClient->SendStringMessage(out.str(), response);

   if (result != ERROR_SUCCESS) {
      Log(LOGLABEL("ERROR: Failed sending command:%s to service, "
                   "error:0x%08lx."),
          cmdString, result);
      return result;
   }
   if (response == PIPE_REPLY_NOT_OK) {
      Log(LOGLABEL("ERROR: Received:REPLY_NOT_OK response from service."));
      return ERROR_GENERIC_COMMAND_FAILED;
   }
   Log(LOGLABEL("Response:*****"));

   // Parse response, token can have spaces in so just read port and
   // then use the rest of the response string as the token
   std::istringstream in(response);
   in >> port;
   token = response.substr(strlen(pipelib::ABIPC_MSG_DELIM) +
           (std::streamoff)in.tellg());

   result = strncpy_s(tokenPtr, maxTokenLen, token.c_str(), _TRUNCATE);

   if (result != ERROR_SUCCESS) {
      Log(LOGLABEL("ERROR: Failed to copy token, error:0x%08lx."), result);
   }

   if (port <= 0 || port > 65535) {
      Log(LOGLABEL("ERROR: Failed to parse port, port:%d."), port);
      result = ERROR_INVALID_DATA;
   } else {
      *portPtr = port;
   }

   return result;
}


extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_PrepareSession2(DWORD sessionId,       // IN
                         char *tokenPtr,        // OUT
                         size_t maxTokenLen,    // IN
                         const char *addrIPv4,  // IN
                         const char *addrIPv6,  // IN
                         int *portPtr)          // IN/OUT
{
   return AppBlast_PrepareSessionHelper(pipelib::ABIPC_PREPARE_SESSION,
                                        sessionId, tokenPtr, maxTokenLen,
                                        addrIPv4, addrIPv6, portPtr, true);
}


extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_ShadowPrepareSession(DWORD sessionId,       // IN
                              char *tokenPtr,        // OUT
                              size_t maxTokenLen,    // IN
                              const char *addrIPv4,  // IN
                              const char *addrIPv6,  // IN
                              int *portPtr,          // IN/OUT
                              bool allowInput)       // IN
{
   return AppBlast_PrepareSessionHelper(pipelib::ABIPC_SHADOW_PREPARE_SESSION,
                                        sessionId, tokenPtr, maxTokenLen,
                                        addrIPv4, addrIPv6, portPtr, allowInput);
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_TerminateSessionEx() --
 *
 *    Tell AppBlast to terminate session with given token and reason.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS. On failure, returns an error code.
 *
 * Side Effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_TerminateSessionEx(const char* token,       // IN
                            int reason)              // IN
{
   Log(LOGLABEL("Called with reason:%d."), reason);
   if (!token || strlen(token) == 0) {
      Log(LOGLABEL("ERROR: Invalid empty arguments, token:%p (size:%d)."),
          token, token ? strlen(token) : 0);
      return ERROR_BAD_ARGUMENTS;
   }

   std::string cmd = pipelib::ABIPC_TERMINATE_SESSION_MSG;
   const char * const cmdString = pipelib::GetCommandString(cmd);
   Log(LOGLABEL("Sending command:%s"), cmdString);

   std::ostringstream cmdss;
   cmdss << cmd << pipelib::ABIPC_MSG_DELIM
         << token << pipelib::ABIPC_MSG_DELIM
         << reason;
   cmd = cmdss.str();

   std::string response;
   DWORD result = gRequestPipeClient->SendStringMessage(cmd, response);
   if (result == ERROR_SUCCESS) {
      Log(LOGLABEL("Received response:'%s'"), response.c_str());
   } else {
      Log(LOGLABEL("ERROR: Failed sending command:%s to service, "
                   "error:0x%08lx."),
          cmdString, result);
   }

   return result;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_TerminateSession() --
 *
 *    Tell AppBlast to terminate session with given token.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS. On failure, returns an error code.
 *
 * Side Effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_TerminateSession(const char* token)    // IN
{
   Log(LOGLABEL("called."));
   return AppBlast_TerminateSessionEx(token, VDPCONNECT_RESULT_UNSPECIFIED);
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_AllowInput() --
 *
 *    Tell AppBlast to mute/unmute the input control of the session associated
 *    with the given vAuth.
 *    If allowInput is true, then allow/unmute the input control;
 *    If allowInput is false, then disallow/mute the input control.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS. On failure, returns an error code.
 *
 * Side Effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_AllowInput(const char *vAuth,    // IN
                    bool allowInput)      // IN
{
   if (!vAuth || strlen(vAuth) == 0) {
      Log(LOGLABEL("ERROR: Invalid empty arguments, vAuth:%p (size:%d)."),
          vAuth, vAuth ? strlen(vAuth) : 0);
      return ERROR_BAD_ARGUMENTS;
   }

   std::string cmd = pipelib::ABIPC_ALLOW_INPUT_MSG;
   const char * const cmdString = pipelib::GetCommandString(cmd);
   Log(LOGLABEL("Sending command:%s"), cmdString);

   std::ostringstream cmdss;
   cmdss << cmd << pipelib::ABIPC_MSG_DELIM
         << vAuth << pipelib::ABIPC_MSG_DELIM
         << allowInput ? "1" : "0";;
   cmd = cmdss.str();

   std::string response;
   DWORD result = gRequestPipeClient->SendStringMessage(cmd, response);
   if (result == ERROR_SUCCESS) {
      Log(LOGLABEL("Received response:'%s'"), response.c_str());
   } else {
      Log(LOGLABEL("ERROR: Failed sending command:%s to service, "
                   "error:0x%08lx."),
          cmdString, result);
   }

   return result;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_QueryVersion() --
 *
 *    This method gives min, and max supported versions of AbCtrl dll. Consumer
 *    of this dll can use this method prior to using AppBlast_QueryInterface()
 *    to know the min, and max supported versions of dll.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS. On failure, returns an error code.
 *
 * Side Effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_QueryVersion(uint64* minVersion,    // OUT
                      uint64* maxVersion)    // OUT
{
   if (!minVersion) {
      Log(LOGLABEL("ERROR: Invalid empty argument, minVersion:NULL."));
      return ERROR_BAD_ARGUMENTS;
   }

   if (!maxVersion) {
      Log(LOGLABEL("ERROR: Invalid empty argument, maxVersion:NULL."));
      return ERROR_BAD_ARGUMENTS;
   }

   *minVersion = MIN_ABCTRLAPI_VERSION_UI64;
   *maxVersion = MAX_ABCTRLAPI_VERSION_UI64;

   return ERROR_SUCCESS;
}


/*
 *------------------------------------------------------------------------------
 * AppBlast_QueryInterface() --
 *
 *    This method gives function table for requested version. If consumer
 *    requests for a version lower than MIN_ABCTRLAPI_VERSION_UI64, or higher
 *    than MAX_ABCTRLAPI_VERSION_UI64, the method will return bad argument
 *    error without filling out function table.
 *
 *    Consumer of this dll is responsible for allocating memory for funcTable
 *    and must provide the buffer size. The min, and max supported versions of
 *    dll cab be requested using AppBlast_QueryVersion() method.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS. On failure, returns an error code.
 *
 * Side Effects:
 *    None.
 *------------------------------------------------------------------------------
 */

extern "C" __declspec(dllexport)
DWORD __cdecl
AppBlast_QueryInterface(uint64 requestedVersion,   // IN
                        void* funcTable,           // IN/OUT
                        size_t funcTableSize)      // IN
{
   InitializeLogging();

   if (requestedVersion < MIN_ABCTRLAPI_VERSION_UI64 ||
       requestedVersion > MAX_ABCTRLAPI_VERSION_UI64) {
      Log(LOGLABEL("ERROR: Requested an unsupported AbCtrl API version:%I64u "
                   "(Min supported version:%I64u, Max supported "
                   "version:%I64u)."),
          requestedVersion, MIN_ABCTRLAPI_VERSION_UI64,
          MAX_ABCTRLAPI_VERSION_UI64);
      return ERROR_BAD_ARGUMENTS;
   }

   if (!funcTable) {
      Log(LOGLABEL("ERROR: Invalid empty argument, funcTable:NULL."));
      return ERROR_BAD_ARGUMENTS;
   }

   size_t expectedStructSize = 0;
   DWORD result = AbCtrlStructSize(requestedVersion, &expectedStructSize);
   if (result != ERROR_SUCCESS) {
      Log(LOGLABEL("ERROR: Failed to query AbCtrl API struct size for "
                   "version:%I64u."),
          requestedVersion);
      return ERROR_NOT_SUPPORTED;
   }

   if (funcTableSize < expectedStructSize) {
      Log(LOGLABEL("Insufficient struct size. funcTableSize is %Iu, required "
                   "size is %Iu."),
          funcTableSize, expectedStructSize);
      return ERROR_BAD_ARGUMENTS;
   }

   Log(LOGLABEL("AbCtrl API requested version: %I64u."), requestedVersion);

   AbCtrl_API* ft = static_cast<AbCtrl_API *>(funcTable);
   ft->version = requestedVersion;

   switch (requestedVersion) {
      case 3:
         ft->v3.ShadowPrepareSession = AppBlast_ShadowPrepareSession;
         ft->v3.AllowInput = AppBlast_AllowInput;
         // NOTE: Do not break, fall through to version 2

      case 2:
         ft->v2.PrepareSession = AppBlast_PrepareSession2;
         ft->v2.SetConnectCallback = AppBlast_SetConnectCallbackV2;
         // NOTE: Do not break, fall through to version 1

      case 1:
         ft->v1.Initialize = AbCtrl_Initialize;
         ft->v1.Cleanup = AbCtrl_Cleanup;
         ft->v1.IsInstalled = AppBlast_IsInstalled;
         ft->v1.IsInUse = AppBlast_IsInUse;
         ft->v1.IsRunning = AppBlast_IsRunning;
         ft->v1.Start = AppBlast_Start;
         ft->v1.Stop = AppBlast_Stop;
         ft->v1.SetConnectCallback = AppBlast_SetConnectCallback;
         ft->v1.PrepareSessionEx = AppBlast_PrepareSessionEx;
         ft->v1.TerminateSessionEx = AppBlast_TerminateSessionEx;
         ft->v1.GetStatus = AppBlast_GetStatus;
         ft->v1.GetIpAndPort = AppBlast_GetIpAndPort;
         break;

      default:
         Log(LOGLABEL("ERROR: Requested an unsupported AbCtrl API "
                      "version:%I64u (Min supported version:%I64u, Max "
                      "supported version: %I64u)."),
             requestedVersion, MIN_ABCTRLAPI_VERSION_UI64,
             MAX_ABCTRLAPI_VERSION_UI64);
         return ERROR_BAD_ARGUMENTS;
   }

   Log(LOGLABEL("Query AbCtrl API version:%I64u completed successfully."),
       requestedVersion);
   return ERROR_SUCCESS;
}


/*
 *------------------------------------------------------------------------------
 * AbCtrlStructSize() --
 *
 *    This method gives size of AbCtrl_API structure associated with a version.
 *
 * Results:
 *    On success, returns ERROR_SUCCESS. On failure, returns an error code.
 *
 * Side Effects:
 *    None.
 *------------------------------------------------------------------------------
 */

DWORD
AbCtrlStructSize(uint64 version,    // IN
                 size_t* size)      // IN/OUT
{
   if (version < MIN_ABCTRLAPI_VERSION_UI64 ||
       version > MAX_ABCTRLAPI_VERSION_UI64) {
      Log(LOGLABEL("ERROR: Requested an unsupported AbCtrl API version:%I64u "
                   "(Min supported version:%I64u, Max supported "
                   "version:%I64u)."),
          version, MIN_ABCTRLAPI_VERSION_UI64, MAX_ABCTRLAPI_VERSION_UI64);
      return ERROR_BAD_ARGUMENTS;
   }

   if (!size) {
      Log(LOGLABEL("ERROR: Invalid empty argument, size:NULL."));
      return ERROR_BAD_ARGUMENTS;
   }

   switch (version) {
      case 1:
         *size = offsetof(AbCtrl_API, v1) + sizeof(((AbCtrl_API*)0)->v1);
         break;

      case 2:
         *size = offsetof(AbCtrl_API, v2) + sizeof(((AbCtrl_API*)0)->v2);
         break;

      case 3:
         *size = offsetof(AbCtrl_API, v3) + sizeof(((AbCtrl_API*)0)->v3);
         break;

      default:
         Log(LOGLABEL("ERROR: Requested an unsupported AbCtrl API "
                      "version:%I64u (Min supported version:%I64u, Max "
                      "supported version: %I64u)."),
             version, MIN_ABCTRLAPI_VERSION_UI64, MAX_ABCTRLAPI_VERSION_UI64);
         return ERROR_BAD_ARGUMENTS;
   }

   return ERROR_SUCCESS;
}


/*
 *------------------------------------------------------------------------------
 * InitializeDll() --
 *
 *    Does the work for both AbCtrl_Initialize() and AbCtrl_InitializeTest().
 *
 * Results:
 *    ERROR_SUCCESS if initialization was successful. If the named pipe server
 *    could not be created, ERROR_ACCESS_DENIED is returned.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

static DWORD
InitializeDll(bool securePipes)     // IN
{
   DWORD result = ERROR_INTERNAL_ERROR;

   InitializeLogging();

   /* Start thread that listens for Blast event pipe messages. */
   if (securePipes) {
      /*
       * Only accept connections - and therefore events - from LocalSystem.
       * (Blast service and worker both run as LocalSystem). If you run Blast
       * standalone (e.g. when developing) you will need to initialize Abctrl with
       * securePipes = false, otherwise it won't be able to write session events to
       * this pipe server.
       */
      gEventPipeSA = pipelib::PipeSecurityAttr::CreateLocalSystemInstance(GENERIC_ALL);
   }
   gEventPipeHelper = new EventPipeServerHelper();
   gEventPipeServer = new pipelib::PipeServer(pipelib::ABIPC_EVENT_PIPE_NAME, gEventPipeHelper, gEventPipeSA);

   Log(LOGLABEL("starting event pipe server with %s security"),
       gEventPipeSA ? "LocalSystem" : "no");

   if (!gEventPipeServer->Start()) {
      Log(LOGLABEL("ERROR: Failed to start pipe server."));
      result = ERROR_ACCESS_DENIED;
      goto exit;
   }

   /* Create a client to send requests to AppBlast */
   gRequestPipeClient = new pipelib::PipeClient(pipelib::ABIPC_REQUEST_PIPE_NAME);

   Log(LOGLABEL("abctrl.dll initialized"));

   /*
    * Bug 1206939: attempt to start Blast in case Windows timed out trying
    * to start the service.
    */
   if ((result = AppBlast_Start()) != ERROR_SUCCESS) {
      Log(LOGLABEL("WARN: AppBlast_Start() failed, error:0x%08lx."), result);
      /*
       * Bug 1217253: Do not pass the error back to View Agent since the error
       * might be due to the Blast service being in the process of starting up
       * by Windows between the AppBlast_IsRunning() check and StartService().
       */
   }

   result = ERROR_SUCCESS;

exit:
   if (result != ERROR_SUCCESS) {
      AbCtrl_Cleanup();
   }
   return result;
}


/*
 *------------------------------------------------------------------------------
 * InitializeLogging() --
 *
 *    Initializes the logging for abctrl.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

static void
InitializeLogging()
{
   if (gLogFileH == INVALID_HANDLE_VALUE) {
      /* Open a log file, if a log file name is supplied */
      wchar_t *logName = GetDebugLogName();
      if (logName) {
         gLogFileH = CreateFile(logName,
                                FILE_APPEND_DATA,
                                FILE_SHARE_READ,
                                NULL,
                                OPEN_ALWAYS,
                                FILE_ATTRIBUTE_NORMAL,
                                NULL);
      }
   }
}


/*
 *------------------------------------------------------------------------------
 * GetDebugLogName() --
 *
 *    Look in the registry for a name of a log file, and return it if found. If
 *    missing or unable to read, return NULL.
 *
 * Results:
 *    The value of the log file name, or else NULL.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */

static wchar_t*
GetDebugLogName()
{
   static wchar_t buf[MAX_PATH] = { 0 };
   DWORD err;
   HKEY hKey;

   err = RegOpenKey(HKEY_LOCAL_MACHINE,
                    L"SOFTWARE\\VMware, Inc.\\VMware Blast\\Abctrl",
                    &hKey);
   if (err != ERROR_SUCCESS) {
      return NULL;
   }

   ZeroMemory(buf, sizeof(buf));
   DWORD bufSize = sizeof(buf) - sizeof(wchar_t);
   err = RegQueryValueEx(hKey, L"LogFile", NULL, NULL, (LPBYTE) buf, &bufSize);

   if (err != ERROR_SUCCESS) {
      RegCloseKey(hKey);
      return NULL;
   }

   RegCloseKey(hKey);
   return &buf[0];
}


/*
 *------------------------------------------------------------------------------
 * Log() --
 *
 *    Implement the logging function used by this module
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */

static void
Log(const char *format, ...)     // IN
{
   va_list args;
   va_start(args, format);
   LogV(format, args);
   va_end(args);
}


/*
 *------------------------------------------------------------------------------
 * PipeLog() --
 *
 *    Implement the logging function used by pipelib.
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */

void
pipelib::PipeLog(const char *format, ...)    // IN
{
   va_list args;
   va_start(args, format);
   LogV(format, args);
   va_end(args);
}


/*
 *------------------------------------------------------------------------------
 * LogV() --
 *
 *    Cheap and cheerful logging function. Writes to the debug log file if it
 *    is open, else does nothing. Only developers know how to turn on this
 *    logging.
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */

static void
LogV(const char *format,   // IN
     va_list args)         // IN
{
   if (gLogFileH != INVALID_HANDLE_VALUE) {
      static const char endOfLine[] = { '\r', '\n' };
      DWORD written;

#define LOG_MSG_BUF_SIZE 1024
      char buf[LOG_MSG_BUF_SIZE];

      SYSTEMTIME now;
      GetLocalTime(&now);
      sprintf(buf, "%d-%02d-%02d %02d:%02d:%02d.%03d ",
                   now.wYear, now.wMonth, now.wDay,
                   now.wHour, now.wMinute, now.wSecond, now.wMilliseconds);
      WriteFile(gLogFileH, buf, (DWORD) strlen(buf), &written, NULL);

      vsprintf_s(buf, sizeof(buf), format, args);
      WriteFile(gLogFileH, buf, (DWORD) strlen(buf), &written, NULL);

      WriteFile(gLogFileH, endOfLine, sizeof(endOfLine), &written, NULL);

      FlushFileBuffers(gLogFileH);
   }
   /*
   // uncomment this to have unit test prints error (for troubleshooting)
   else {
      static const char endOfLine[] = { '\r', '\n' };

#define LOG_MSG_BUF_SIZE 1024
      char buf[LOG_MSG_BUF_SIZE];

      SYSTEMTIME now;
      GetLocalTime(&now);
      sprintf(buf, "%d-%02d-%02d %02d:%02d:%02d.%03d ",
                   now.wYear, now.wMonth, now.wDay,
                   now.wHour, now.wMinute, now.wSecond, now.wMilliseconds);
      vsprintf_s(buf, sizeof(buf), format, args);
      printf("%s\n", buf);
   }
   */
}