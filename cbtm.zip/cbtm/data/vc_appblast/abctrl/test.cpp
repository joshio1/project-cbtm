/* **********************************************************
 * Copyright (C) 2012 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

/*
 * test.cpp --
 *
 *    AppBlast Controller Test
 */

#include <windows.h>
#include <string>
#include <vector>
#include <iostream>
#include <stdio.h>
#include <io.h>

/* Session callbacks look like this */
typedef void (*SessionCb)(BOOL, const char*);

/* Function types found in the DLL */
typedef DWORD ( __cdecl *BoolOutFunc)(bool*);
typedef DWORD ( __cdecl *BoolInFunc)(bool);
typedef DWORD ( __cdecl *VoidFunc)();
typedef DWORD ( __cdecl *SetCbFunc)(SessionCb cb);
typedef DWORD ( __cdecl *PrepCnxFunc)(char*, size_t);
typedef DWORD ( __cdecl *TerminateCnxFunc)(const char*);
typedef DWORD ( __cdecl *GetIpAndPortFunc)(bool, char*, size_t, int*);


/* We track the states of sessions as best we can */
typedef enum {
   SESSION_REQUESTED,
   SESSION_STARTED,
   SESSION_TERMINATING,
   SESSION_ENDED
} SessionState;

static inline std::string ToStr(SessionState state) {
   switch (state) {
      case SESSION_REQUESTED: return "REQUESTED";
      case SESSION_STARTED: return "STARTED";
      case SESSION_TERMINATING: return "TERMINATING";
      case SESSION_ENDED: return "ENDED";
   }
   return "?";
}

typedef struct {
   std::string authToken;
   std::string thumbprint;
   SessionState state;
   int count;
} SessionInfo;

/* Functions inside the DLL */
static VoidFunc gInitializeFunc;
static VoidFunc gCleanupFunc;
static BoolOutFunc gInstalledFunc;
static BoolOutFunc gInUseFunc;
static BoolOutFunc gRunningFunc;
static VoidFunc gStartFunc;
static VoidFunc gStopFunc;
static SetCbFunc gSetConnCbFunc;
static PrepCnxFunc gPrepConnFunc;
static TerminateCnxFunc gTermConnFunc;
static GetIpAndPortFunc gIpPortFunc;

/* Local functions */
static std::string parseJsonValue(const std::string& json, const std::string& jsonKey);
static int readSessionNumber();
static void doIpPortQuery();
static int doSessionPrep();
static void doSessionsList();
static void doSessionKill(int index);
static void doSessionOpen(int index);
static void doLoopTest();
static void doReportServerStatus();
static int doCleanup();
static void sessionCallback(BOOL connect, const char* token);

/* Other globals */
static std::vector<SessionInfo> gSessions;
static CRITICAL_SECTION gSessionsLock;
static bool gInteractive;

#define LOCK_SESSION_LIST() EnterCriticalSection(&gSessionsLock)
#define UNLOCK_SESSION_LIST() LeaveCriticalSection(&gSessionsLock)

/*
 *------------------------------------------------------------------------------
 * AppBlastControllerTest() --
 *
 *    NOTE: For illustrative purposes only. Although this file would compile,
 *    it is not included in the build.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *------------------------------------------------------------------------------
 */
int
main(int argc, char* argv[])
{
   InitializeCriticalSection(&gSessionsLock);
   gInteractive = (_isatty(_fileno(stdin)) != 0);
   const char *initFuncName = "AbCtrl_Initialize";
   int retCode = 1;

   if (gInteractive) {
      printf("Controller test started\n");
   }

   /* Scan command line args */
   for (int i = 1; i < argc; i++) {
      if (!strcmp(argv[i], "/u")) {
         initFuncName = "AbCtrl_InitializeTest";
      }
   }

   /* Load the DLL (must be in PATH or current directory) */
   HMODULE libH = LoadLibrary(L"abctrl.dll");
   if (libH == NULL) {
      fprintf(stderr, "Failed to load DLL\n");
      goto out;
   }

   // This just saves code lines:
   #define LOAD_FUNCTION(FPTR, TYPE, NAME) \
      do if ((FPTR = (TYPE) GetProcAddress(libH, NAME)) == NULL) { \
         printf("Failed to locate %s() in DLL, error:0x%08lx.\n", NAME, \
                GetLastError()); \
         goto out; \
      } while (0)

   LOAD_FUNCTION(gInitializeFunc, VoidFunc,         initFuncName);
   LOAD_FUNCTION(gCleanupFunc,    VoidFunc,         "AbCtrl_Cleanup");
   LOAD_FUNCTION(gInstalledFunc,  BoolOutFunc,      "AppBlast_IsInstalled");
   LOAD_FUNCTION(gInUseFunc,      BoolOutFunc,      "AppBlast_IsInUse");
   LOAD_FUNCTION(gRunningFunc,    BoolOutFunc,      "AppBlast_IsRunning");
   LOAD_FUNCTION(gStartFunc,      VoidFunc,         "AppBlast_Start");
   LOAD_FUNCTION(gStopFunc,       VoidFunc,         "AppBlast_Stop");
   LOAD_FUNCTION(gSetConnCbFunc,  SetCbFunc,        "AppBlast_SetConnectCallback");
   LOAD_FUNCTION(gPrepConnFunc,   PrepCnxFunc,      "AppBlast_PrepareSession");
   LOAD_FUNCTION(gTermConnFunc,   TerminateCnxFunc, "AppBlast_TerminateSession");
   LOAD_FUNCTION(gIpPortFunc,     GetIpAndPortFunc, "AppBlast_GetIpAndPort");

   /* Initialize the DLL */
   DWORD err = (*gInitializeFunc)();
   if (err != ERROR_SUCCESS) {
      fprintf(stderr, "Failed to initialize DLL with %s(), error = %ld\n",
              initFuncName,
              err);
      goto out;
   }

   if (gInteractive) {
      printf("DLL loaded and ready (%s)\n", initFuncName);
   }

   /* Register our session callback */
   err = (*gSetConnCbFunc)(sessionCallback);
   if (err != ERROR_SUCCESS) {
      fprintf(stderr, "ERROR: Failed to set session callback, error = %ld\n", err);
      goto out;
   }

   if (gInteractive) {
      printf("Registered session callback\n");
   }

   while (true) {
      std::string cmd;

      if (gInteractive) {
         printf("\n");
         printf("[i]nfo    - Print IP and port information.\n");
         printf("[p]rep    - Prepare a new session.\n");
         printf("[o]pen    - Open browser to AppBlast home page.\n");
         printf("[k]ill    - Terminate a session.\n");
         printf("[l]ist    - List all sessions\n");
         printf("[s]tatus  - Server status\n");
         printf("[t]est    - Loop test\n");
         printf("[c]leanup - Clean up terminated sessions\n");
         printf("[q]uit    - Quit\n");
      }

      // Read next string from stdin
      if (!std::cin.good()) {
         retCode = 0;
         goto out;
      }
      std::cin >> cmd;

      if (cmd == "info" || cmd[0] == 'i') {
         doIpPortQuery();
      } else if (cmd == "prep" || cmd[0] == 'p') {
         doSessionPrep();
         if (gInteractive) {
            doSessionsList();
         }
      } else if (cmd == "open" || cmd[0] == 'o') {
         doSessionOpen(-1);
      } else if (cmd == "kill" || cmd[0] == 'k') {
         doSessionKill(-1);
         if (gInteractive) {
            doSessionsList();
         }
      } else if (cmd == "list" || cmd[0] == 'l') {
         doSessionsList();
      } else if (cmd == "status" || cmd[0] == 's') {
         doReportServerStatus();
      } else if (cmd == "test" || cmd[0] == 't') {
         doLoopTest();
      } else if (cmd == "cleanup" || cmd[0] == 'c') {
         doCleanup();
      } else if (cmd == "quit" || cmd[0] == 'q') {
         retCode = 0;
         goto out;
      } else {
         printf("Invalid command \"%s\".\n", cmd.c_str());
      }
   }

out:
   /* Cleanup the DLL */
   if (gCleanupFunc) {
      (*gCleanupFunc)();
   }

   FreeLibrary(libH);
   return retCode;
}


/*
 *------------------------------------------------------------------------------
 * sessionCallback() --
 *
 *    This is our session start/end callback that abctrl.dll will invoke when
 *    sessions start and end.
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */
/* This is our session callback */
void sessionCallback(BOOL connect, const char* token)
{
   LOCK_SESSION_LIST();

   bool found = false;
   for (size_t i = 0; i < gSessions.size(); i++) {
      if (gSessions[i].authToken == token) {
         int oldCount = gSessions[i].count;
         gSessions[i].count += (connect ? 1 : -1);
         bool report = false;

         if (oldCount == 0 && gSessions[i].count> 0) {
            gSessions[i].state = SESSION_STARTED;
            report = true;
         } else if (oldCount > 0 && gSessions[i].count == 0) {
            gSessions[i].state = SESSION_ENDED;
            report = true;
         }

         if (report) {
            printf("AppBlast session %s is %s\n",
                   token,
                   ToStr(gSessions[i].state).c_str());
         }

         found = true;
         break;
      }
   }

   if (!found) {
      printf("Unknown AppBlast session callback (%s)\n", token);
   }

   UNLOCK_SESSION_LIST();
}


/*
 *------------------------------------------------------------------------------
 * parseJsonValue() --
 *
 *    Parse a JSON-formatted string and return the value for a given
 *    key. Not 100% foolproof.
 *
 * Results:
 *    Value for key.
 *------------------------------------------------------------------------------
 */
static std::string
parseJsonValue(const std::string& json, const std::string& jsonKey)
{
   size_t p1 = json.find(jsonKey);
   size_t p2 = json.find("\"", p1 + jsonKey.size() + 2) + 1;
   size_t p3 = json.find("\"", p2 + 1);
   return json.substr(p2, p3 - p2);
}


/*
 *------------------------------------------------------------------------------
 * readSessionNumber() --
 *
 *    Prompt the user to choose one of the known sessions, and return
 *    its index. If there is only one session, returns '0' without the
 *    prompt. Returns -1 if there are no sessions.
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */
static int
readSessionNumber()
{
   int result;

   size_t nSessions = gSessions.size();
   if (nSessions == 0) {
      result = -1;
      goto out;
   } else if (nSessions == 1) {
      result = 0;
      goto out;
   }

   if (gInteractive) {
      doSessionsList();
      printf("Enter session (1 to %d): ", gSessions.size());
      fflush(stdout);
   }

   while (true) {
      int which;
      scanf_s("%d", &which);
      if (which >= 1 && which <= (int) gSessions.size()) {
         result = (which - 1);
         goto out;
      }
   }

out:
   return result;
}


/*
 *------------------------------------------------------------------------------
 * doIpPortQuery() --
 *
 *    Query AppBlast for IP and port information, print it, and return.
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */
static void
doIpPortQuery()
{
   /* Get IP and Port */
   bool secureMode = true;
   char ip[32] = { 0 };
   int port = 0;

   DWORD err = (*gIpPortFunc)(secureMode, ip, sizeof(ip), &port);
   if (err != ERROR_SUCCESS) {
      printf("ERROR: Failed to get IP/port, error = %ld\n", err);
      return;
   }

   printf("AppBlast reports IP %s and %s port %d\n",
          ip,
          secureMode ? "secure" : "unsecure",
          port);
}


/*
 *------------------------------------------------------------------------------
 * doSessionPrep() --
 *
 *    Instruct AppBlast to prepare a new session, print the session information
 *    (full JSON data), and return.
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */
static int
doSessionPrep()
{
   char jbuf[4096];

   /* Prepare a session, print the token */
   DWORD err = (*gPrepConnFunc)(jbuf, sizeof(jbuf));
   if (err != ERROR_SUCCESS) {
      printf("WARNING: Failed to prepare a connection, error = %ld\n", err);
      return -1;
   }

   // Parse the JSON (only a test app so doesn't get too error-proof)
   SessionInfo s;
   s.authToken = parseJsonValue(jbuf, "a");
   s.thumbprint = parseJsonValue(jbuf, "thumbprint");
   s.state = SESSION_REQUESTED;
   s.count = 0;
   printf("Prepped session %s\n", s.authToken.c_str());

   LOCK_SESSION_LIST();
   gSessions.push_back(s);
   int index = (int) gSessions.size() - 1;
   UNLOCK_SESSION_LIST();

   return index;
}


/*
 *------------------------------------------------------------------------------
 * doSessionsList() --
 *
 *    List all the sessions we know about.
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */
static void
doSessionsList()
{
   LOCK_SESSION_LIST();

   for (unsigned int i = 0; i < gSessions.size(); i++) {
      printf("   (%d) %s x%d [%s]\n",
             i + 1,
             gSessions[i].authToken.c_str(),
             gSessions[i].count,
             ToStr(gSessions[i].state).c_str());
   }

   UNLOCK_SESSION_LIST();
}


/*
 *------------------------------------------------------------------------------
 * doSessionKill() --
 *
 *    Ask for a session, and tell AppBlast to kill it. If there is only one
 *    session, it is killed without prompting.
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */
static void
doSessionKill(int index)
{
   std::string token;
   DWORD err;

   if (gSessions.empty()) {
      printf("No sessions!\n");
      return;
   }

   /* If no index specified, ask for one and try again */
   if (index < 0) {
      index = readSessionNumber();
      doSessionKill(index);
      return;
   }

   LOCK_SESSION_LIST();
   gSessions[index].state = SESSION_TERMINATING;
   token = gSessions[index].authToken;
   UNLOCK_SESSION_LIST();

   printf("Killing session %s\n", token.c_str());
   err = (*gTermConnFunc)(token.c_str());
   if (err != ERROR_SUCCESS) {
      printf("ERROR: Failed to terminate session: error = %ld\n", err);
   }

   printf("Session terminated.\n");
}


/*
 *------------------------------------------------------------------------------
 * doSessionOpen() --
 *
 *    Launch a browser window to display the AppBlast home page, using a
 *    session token that was previously requested.
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */
static void
doSessionOpen(int index)
{
   // XXX cs?

   if (gSessions.empty()) {
      printf("No sessions!\n");
      return;
   }

   /* If no index specified, ask for one and try again */
   if (index < 0) {
      index = readSessionNumber();
      doSessionOpen(index);
      return;
   }

   printf("Launching session %s\n", gSessions[index].authToken.c_str());

   std::string cmd = "start http://localhost:22080/d/1/?vauth=";
   cmd += gSessions[index].authToken;
   system(cmd.c_str());

   printf("Session opened.\n");
}


/*
 *------------------------------------------------------------------------------
 * doLoopTest() --
 *
 *    Keep preparing, opening and killing AppBlast sessions. A stress test to
 *    see what breaks first: AppBlast or your browser.
 *
 * Results:
 *    None. Runs for ever, or until no sessions can be prepared.
 *------------------------------------------------------------------------------
 */
static void
doLoopTest()
{
   int numIterations;
   printf("Enter number of iterations (-1 for infinite): ");
   fflush(stdout);
   scanf_s("%d", &numIterations);

   int sleepDelay;
   printf("Enter sleep between iterations (ms): ");
   fflush(stdout);
   scanf_s("%d", &sleepDelay);

   int i = 0;
   while (i < numIterations || numIterations < 0) {
      // Prepare a session
      printf("Iteration %d of %d:\n", i+1, numIterations);
      int si = doSessionPrep();
      if (si < 0) {
         return;
      }

      // Open a browser to the session
      std::string token = gSessions[si].authToken;
      doSessionOpen(si);
      Sleep(sleepDelay);

      // Wait for it to connect...
      while (gSessions[si].state != SESSION_STARTED) {
         printf("Iteration %d: Waiting for session %s to open...\n", i, token.c_str());
         Sleep(sleepDelay);
      }

      // Now kill it
      doSessionKill(si);

      i++;
   }

   printf("Test complete:\n");
   doSessionsList();

   return;
}


/*
 *------------------------------------------------------------------------------
 * doReportServerStatus() --
 *
 *    Report on AppBlast service status: Is it installed? Is it running?
 *    Is it in use?
 *
 * Results:
 *    None.
 *------------------------------------------------------------------------------
 */
static void
doReportServerStatus()
{
   /* Service install state */
   bool installed;
   DWORD err = (gInstalledFunc)(&installed);
   if (err != ERROR_SUCCESS) {
      printf("WARNING: Failed to query install status, error %ld\n", err);
   } else {
      printf("Service is %s\n", installed? "installed" : "not installed");
   }

   /* Get current service state */
   bool running;
   err = (gRunningFunc)(&running);
   if (err != ERROR_SUCCESS) {
      printf("WARNING: Failed to query service status, error %ld\n", err);
   } else {
      printf("Service is %s\n", running ? "running" : "stopped");
   }

   /* In use? */
   bool inUse;
   err = (*gInUseFunc)(&inUse);
   if (err != ERROR_SUCCESS) {
      printf("WARNING: Failed to query in-use status, error %ld\n", err);
   } else {
      printf("Service is %s\n", inUse ? "in use" : "idle");
   }

  /* Toggle the service? */
   printf("%s the service?\n", running ? "Stop" : "Start");
   char input[8];
   scanf_s("%7s", input, 8);
   if (input[0] == 'y') {
      err = (running ? (gStopFunc)() : (gStartFunc)());
      if (err != ERROR_SUCCESS) {
         printf("WARNING: Failed to change service status, error %ld\n", err);
      }
   }
}


/*
 *------------------------------------------------------------------------------
 * doCleanup() --
 *
 *    Clean up the known session list by discarding any that are known to have
 *    ended.
 *
 * Results:
 *    Number of sessions cleaned up.
 *------------------------------------------------------------------------------
 */
static int
doCleanup()
{
   int count = 0;

   LOCK_SESSION_LIST();
   std::vector<SessionInfo>::iterator i;
   for (i = gSessions.begin(); i != gSessions.end(); ) {
      SessionInfo si = *i;

      if (si.state == SESSION_ENDED) {
         i = gSessions.erase(i);
         count++;
      } else {
         i++;
      }
   }
   UNLOCK_SESSION_LIST();

   printf("Cleaned up %d sessions\n", count);
   return count;
}