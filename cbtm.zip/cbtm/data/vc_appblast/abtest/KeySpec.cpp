/* **********************************************************
 * Copyright (C) 2014 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

#include <string>
#include <vector>
#include <algorithm>
#include <ostream>
#include <fstream>

#include <stdio.h>
#include <crtdbg.h>
#include <Windows.h>

#include "abtest.h"
#include "KeySpec.h"
#include "KeyboardHandler.h"
#include "appBlastUtil.h"

using std::vector;
using std::string;
using std::ostringstream;
using std::ifstream;
using std::endl;
using namespace Json;

/*
 *-----------------------------------------------------------------------------
 * KeySpec::FromJson
 *
 *    Attempts to construct a collection of KeySpec objects from the given
 *    stream of JSON text.
 *
 * Results:
 *    true if the given JSON stream was formatted properly and construction was
 *    successful, false otherwise.  If false, errorMessage will describe why
 *    construction failed.
 *
 * Side effects:
 *    On success, result will contain a collection of the constructed KeySpec
 *    objects.
 *-----------------------------------------------------------------------------
 */
bool
KeySpec::FromJson(ifstream& json,          // IN
                  vector<KeySpec> &result, // OUT
                  string &errorMessage)    // OUT
{
   vector<KeySpec> keySpecs;
   Reader reader;
   Value rootValue, keypressesValue;
   if (!reader.parse(json, rootValue)) {
      errorMessage = "JSON parsing failed: " + reader.getFormatedErrorMessages();
      return false;
   }

   /*
    * Keyspecs must be an object with a 'keypresses' array field and an
    * optional 'description' string field.
    */
   if (rootValue.type() != objectValue) {
      errorMessage = "JSON input must be an object.";
      return false;
   }
   keypressesValue = rootValue["keypresses"];
   if (keypressesValue.isNull() || keypressesValue.type() != arrayValue) {
      errorMessage = "JSON input must have a 'keypresses' array field.";
      return false;
   }

   // Iterate over each object in the 'keypresses' array
   for (Value::iterator currObjIter = keypressesValue.begin();
        currObjIter != keypressesValue.end();
        ++currObjIter) {
      KeySpec currKeySpec;
      Value currObj = *currObjIter;

      // Create a single KeySpec object from the current JSON object.
      if (!KeySpec::FromJson(currObj, currKeySpec, errorMessage)) {
         return false;
      }

      keySpecs.push_back(currKeySpec);
   }

   result = keySpecs;
   return true;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::KeySpec
 *
 *    Construct a KeySpec with fields set to default values.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *-----------------------------------------------------------------------------
 */
KeySpec::KeySpec() :
      mTag(""),
      mKeycode(0),
      mUp(false), mUnicode(false), mAppMode(false),
      mLayout(0),
      mOut(vector<KEYBDINPUT>())
{
   bool noneDown[3] = {false, false, false};
   this->InitDownKeys(noneDown);
   mKbHandler = new KeyboardHandler;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::KeySpec
 *
 *    Copy constructor to construct on KeySpec from another.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *-----------------------------------------------------------------------------
 */
KeySpec::KeySpec(const KeySpec &other) // IN
{
   this->Init(other.mTag,
              other.mKeycode,
              other.mUp, other.mUnicode, other.mAppMode,
              other.mLayout,
              other.mDownKeys,
              other.mOut);
   mKbHandler = new KeyboardHandler;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::~KeySpec
 *
 *    Destruct a KeySpec.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *-----------------------------------------------------------------------------
 */
KeySpec::~KeySpec()
{
   delete mKbHandler;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::operator=
 *
 *    Assignment operator.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *-----------------------------------------------------------------------------
 */
KeySpec&
KeySpec::operator=(const KeySpec &other) // IN
{
   if (this == &other) return *this;
   this->Init(other.mTag,
              other.mKeycode,
              other.mUp, other.mUnicode, other.mAppMode,
              other.mLayout,
              other.mDownKeys,
              other.mOut);
   return *this;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::Assert
 *
 *    Assert that passing the KeySpec's input fields to ProcessKey produces the
 *    KeySpec's output.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *-----------------------------------------------------------------------------
 */
void
KeySpec::Assert() const
{
   vector<INPUT> inputs;
   CHECK(mKbHandler->ProcessKey(this->mKeycode,
                             this->mUp,
                             this->mUnicode,
                             this->mAppMode,
                             this->mDownKeys,
                             this->mLayout,
                             inputs));
   if (inputs.size() != this->mOut.size()) {
      ostringstream msg;
      msg << "ProcessKey (keycode: " << this->mKeycode << ") produced ";
      msg << inputs.size() << " INPUT structure";
      msg << ((inputs.size() == 1) ? ("") : ("s"));
      msg << ", Expected " << this->mOut.size();
      msg << " INPUT structure" << ((this->mOut.size() == 1) ? ("") : ("s")) << endl;
      msg << "Test tag: " << this->mTag << endl;
      msg << "\tdownKeys[0] = " << this->mDownKeys[0] << endl;
      msg << "\tdownKeys[1] = " << this->mDownKeys[1] << endl;
      msg << "\tdownKeys[2] = " << this->mDownKeys[2] << endl;
      msg << "\tmUnicode = " << this->mUnicode;
      CHECK_MSG(false, msg.str());
   }

   for (int outPos = 0; outPos < (int)inputs.size(); ++outPos) {
      CHECK_EQUAL_MSG(this->mOut[outPos].wVk, inputs[outPos].ki.wVk, "wVk: " + this->mTag);
      CHECK_EQUAL_MSG(this->mOut[outPos].wScan, inputs[outPos].ki.wScan, "wScan: " + this->mTag);
      CHECK_EQUAL_MSG(this->mOut[outPos].dwFlags, inputs[outPos].ki.dwFlags, "dwFlags: " + this->mTag);
      CHECK_EQUAL_MSG(this->mOut[outPos].time, inputs[outPos].ki.time, "time: " + this->mTag);
   }
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::FromJson
 *
 *    Attempts to construct a single KeySpec object from the given Json::Value
 *    object.
 *
 * Results:
 *    true if construction is successful, false otherwise.  If false,
 *    errorMessage will describe why construction failed.
 *
 * Side effects:
 *    On success, result will contain the constructed KeySpec object.
 *-----------------------------------------------------------------------------
 */
bool
KeySpec::FromJson(const Value &json,    // IN
                  KeySpec &result,      // OUT
                  string &errorMessage) // OUT
{
   /*
    * Each element of the array must be an object with required members
    *'in' and 'out'.  The 'tag' member is optional.
    */
   if (json.type() != objectValue) {
      errorMessage = "JSON input must be an array of objects.";
      return false;
   }
   if (!json.isMember("in") || json["in"].type() != objectValue) {
      errorMessage = "KeySpec JSON object must have an 'in' member that is an object.";
      return false;
   }
   if (!json.isMember("out") || json["out"].type() != arrayValue) {
      errorMessage = "KeySpec JSON object must have an 'out' member that is an array.";
      return false;
   }

   // Grab the 'tag' member if it is present.
   if (json.isMember("tag")) {
      string tag = json["tag"].asString();
      result.mTag = tag;
   } else {
      result.mTag = "";
   }

   // Process the 'in' member.
   if (!KeySpec::ProcessInKeySpec(json["in"], result, errorMessage)) {
      return false;
   }

   // Process each object of the 'out' array.
   for (Value::const_iterator outIt = json["out"].begin();
        outIt != json["out"].end();
        ++outIt) {
      if (!KeySpec::ProcessOutKeySpec(*outIt, result, errorMessage)) {
         return false;
      }
   }

   return true;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::ProcessInKeySpec
 *
 *    Processes the 'in' member of a JSON key spec.
 *
 * Results:
 *    true if processing is successful, false otherwise.  If false,
 *    errorMessage will describe why processing failed.
 *
 * Side effects:
 *    The given result KeySpec will have the input fields set to the values
 *    from the given Json::Value object.
 *-----------------------------------------------------------------------------
 */
bool
KeySpec::ProcessInKeySpec(const Value &json,    // IN
                          KeySpec &result,      // OUT
                          string &errorMessage) // OUT
{
   if (!KeySpec::CheckMemberType(json, "keycode", intValue, errorMessage)) {
      return false;
   }
   result.mKeycode = json["keycode"].asInt();

   if (!KeySpec::CheckMemberType(json, "up", booleanValue, errorMessage)) {
      return false;
   }
   result.mUp = json["up"].asBool();

   if (!KeySpec::CheckMemberType(json, "unicode", booleanValue, errorMessage)) {
      return false;
   }
   result.mUnicode = json["unicode"].asBool();

   if (!KeySpec::CheckMemberType(json, "appMode", booleanValue, errorMessage)) {
      return false;
   }
   result.mAppMode = json["appMode"].asBool();

   if (!KeySpec::CheckMemberType(json, "lang", stringValue, errorMessage)) {
      return false;
   }
   string lang = json["lang"].asString();
   if (lang == "EN") {
      HKL en = LoadKeyboardLayout(L"00000409", KLF_ACTIVATE);
      if (NULL == en) {
         errorMessage = "Unable to load EN keyboard layout: " + GetLastError();
         return false;
      }
      result.mLayout = en;
   } else if (lang == "FR") {
      HKL fr = LoadKeyboardLayout(L"0000040C", KLF_ACTIVATE);
      if (NULL == fr) {
         errorMessage = "Unable to load FR keyboard layout: " + GetLastError();
         return false;
      }
      result.mLayout = fr;
   } else {
      errorMessage = "Unknown 'lang' key spec  member value '" + lang + ".";
      return false;
   }

   if (!KeySpec::CheckMemberType(json, "downKeys", arrayValue, errorMessage)) {
      return false;
   } else if (json["downKeys"].size() != 3 ||
              json["downKeys"][(UInt)0].type() != booleanValue ||
              json["downKeys"][1].type() != booleanValue ||
              json["downKeys"][2].type() != booleanValue) {
      errorMessage =
         "'downKeys' member of key spec must be an array of three boolean values";
      return false;
   }
   bool downKeys[NUM_DOWN_KEYS];
   downKeys[0] = json["downKeys"][(UInt)0].asBool();
   downKeys[1] = json["downKeys"][1].asBool();
   downKeys[2] = json["downKeys"][2].asBool();
   result.InitDownKeys(downKeys);

   return true;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::ProcessOutKeySpec
 *
 *    Processes the 'out' member of a JSON key spec.
 *
 * Results:
 *    true if processing is successful, false otherwise.  If false,
 *    errorMessage will describe why processing failed.
 *
 * Side effects:
 *    The given result KeySpec will have the output fields set to the values
 *    from the given Json::Value object.
 *-----------------------------------------------------------------------------
 */
bool
KeySpec::ProcessOutKeySpec(const Value &json,    // IN
                           KeySpec &result,      // OUT
                           string &errorMessage) // OUT
{
   KEYBDINPUT out;

   if (!KeySpec::CheckMemberType(json, "vk", intValue, errorMessage)) {
      return false;
   }
   out.wVk = json["vk"].asInt();

   if (!KeySpec::CheckMemberType(json, "scan", intValue, errorMessage)) {
      return false;
   }
   out.wScan = json["scan"].asInt();

   if (!KeySpec::ProcessFlags(json, out, errorMessage)) {
      return false;
   }

   if (!KeySpec::CheckMemberType(json, "time", intValue, errorMessage)) {
      return false;
   }
   out.time = json["time"].asInt();

   result.mOut.push_back(out);
   return true;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::ProcessFlags
 *
 *    Processes the 'flags' member of a JSON key spec.
 *
 * Results:
 *    true if processing is successful, false otherwise.  If false,
 *    errorMessage will describe why processing failed.
 *
 * Side effects:
 *    The given result KEYBDINPUT structure will have the dwFlags field set to
 *    bitwise or of all the values from the given Json::Value array after
 *    mapping the string values in the array to corresponding integer flags.
 *-----------------------------------------------------------------------------
 */
bool
KeySpec::ProcessFlags(const Value &json,    // IN
                      KEYBDINPUT &result,   // OUT
                      string &errorMessage) // OUT
{
   DWORD flags = 0;

   if (!KeySpec::CheckMemberType(json, "flags", arrayValue, errorMessage)) {
      return false;
   }

   // Process each flag in the flags array.
   for (Value::const_iterator flagIt = json["flags"].begin();
        flagIt != json["flags"].end();
        ++flagIt) {
      if ((*flagIt).type() != stringValue) {
         errorMessage = "All values of the 'flags' member must be strings.";
         return false;
      }
      string flag = (*flagIt).asString();

      if (flag == "KEYUP") {
         flags |= KEYEVENTF_KEYUP;
      } else if (flag == "UNICODE") {
         flags |= KEYEVENTF_UNICODE;
      } else if (flag == "EXTENDEDKEY") {
         flags |= KEYEVENTF_EXTENDEDKEY;
      } else {
         errorMessage = "Unknown flag '" + flag + "'.";
         return false;
      }
   }

   result.dwFlags = flags;
   return true;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::ValueTypeToString
 *
 *    Converts the given Json::ValueType enum value to a string.
 *
 * Results:
 *    The string representation of the given Json::ValueType.
 *
 * Side effects:
 *    None.
 *-----------------------------------------------------------------------------
 */
string
KeySpec::ValueTypeToString(ValueType type) // IN
{
   switch (type) {
   case nullValue:    return "nullValue";
   case intValue:     return "intValue";
   case uintValue:    return "uintValue";
   case realValue:    return "realValue";
   case stringValue:  return "stringValue";
   case booleanValue: return "booleanValue";
   case arrayValue:   return "arrayValue";
   case objectValue:  return "objectValue";
   default:           return "Unknown";
   }
}

void
KeySpec::PrintObjectMembers(const Value &obj) {
   CHECK(obj.type() == objectValue);

   Value::Members objMemberNames = obj.getMemberNames();
   for (Value::Members::const_iterator currMemberName = objMemberNames.begin();
        currMemberName != objMemberNames.end();
        ++currMemberName) {
      printf("keypair member name=%s type=%s\n",
         currMemberName->c_str(),
         KeySpec::ValueTypeToString(obj[*currMemberName].type()).c_str());
   }
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::CheckMemberType
 *
 *    Checks that the member named 'memberName' of the given Json::Value exists
 *    and is of type 'type'.
 *
 * Results:
 *    true if the member exists and has the correct type, false otherwise.  If
 *    false, errorMessage will describe what check failed.
 *
 * Side effects:
 *    None.
 *-----------------------------------------------------------------------------
 */
bool
KeySpec::CheckMemberType(const Value &json,        // IN
                         const string &memberName, // IN
                         ValueType type,           // IN
                         string &errorMessage)     // OUT
{
   if (!json.isMember(memberName)) {
      errorMessage = "Key spec must have a '" + memberName + "' member.";
      return false;
   } else if (json[memberName].type() != type) {
      errorMessage = "'" + memberName + "' member of key spec must be a(n) " +
         KeySpec::ValueTypeToString(type) + ".";
      return false;
   }
   return true;
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::Init
 *
 *    Init the fields of KeySpec.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    The fields of the KeySpec will be set to the given values.
 *-----------------------------------------------------------------------------
 */
void
KeySpec::Init(const string &tag,                   // IN
              int keycode,                         // IN
              bool up, bool unicode, bool appMode, // IN
              HKL layout,                          // IN
              const bool downKeys[],               // IN
              const vector<KEYBDINPUT> &out)       // IN
{
   this->mTag = tag;
   this->mKeycode = keycode;
   this->mUp = up;
   this->mUnicode = unicode;
   this->mAppMode = appMode;
   this->mLayout = layout;
   this->mOut = out;
   this->InitDownKeys(downKeys);
}

/*
 *-----------------------------------------------------------------------------
 * KeySpec::InitDownKeys
 *
 *    Init the down keys of the KeySpec.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    The down keys of the KeySpec will be set to the given values.
 *-----------------------------------------------------------------------------
 */
void
KeySpec::InitDownKeys(const bool downKeys[]) // IN
{
   for (int pos = 0; pos < NUM_DOWN_KEYS; pos++) {
      mDownKeys[pos] = downKeys[pos];
   }
}
