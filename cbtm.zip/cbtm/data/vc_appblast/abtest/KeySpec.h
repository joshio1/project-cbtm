/* **********************************************************
 * Copyright (C) 2011 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

#pragma once

#include <string>
#include <vector>
#include <fstream>

#include <json/json.h>
#include <Windows.h>
#include "KeyboardHandler.h"

/*
 * class KeySpec
 *
 *   Represents an input/output pair for use with testing the ProcessKey
 *   function. The input fields of a KeySpec should produce the collection of
 *   KEYBDINPUT structures as output.
 */
class KeySpec {
public:
   static bool FromJson(std::ifstream& json,
                        std::vector<KeySpec> &result,
                        std::string &errorMessage);

   KeySpec();
   KeySpec(const KeySpec &other);
   KeySpec& operator=(const KeySpec &other);
   ~KeySpec();

   void Assert() const;

private:
   static bool FromJson(const Json::Value &json,
                        KeySpec &result,
                        std::string &errorMessage);

   static bool ProcessInKeySpec(const Json::Value &json,
                                KeySpec &result,
                                std::string &errorMessage);

   static bool ProcessOutKeySpec(const Json::Value &json,
                                 KeySpec &result,
                                 std::string &errorMessage);

   static bool ProcessFlags(const Json::Value &json,
                            KEYBDINPUT &result,
                            std::string &errorMessage);

   static std::string ValueTypeToString(Json::ValueType type);

   static void PrintObjectMembers(const Json::Value &obj);

   static bool CheckMemberType(const Json::Value &json,
                        const std::string &memberName,
                        Json::ValueType type,
                        std::string &errorMessage);

   void Init(const std::string &tag,
             int keycode,
             bool up, bool unicode, bool appMode,
             HKL layout,
             const bool downKeys[],
             const std::vector<KEYBDINPUT> &out);

   void InitDownKeys(const bool downKeys[]);

   std::string mTag;
   int mKeycode;
   bool mUp, mUnicode, mAppMode;
   HKL mLayout;
   bool mDownKeys[3];
   std::vector<KEYBDINPUT> mOut;
   KeyboardHandler *mKbHandler;
};
