/* **********************************************************
 * Copyright (C) 2012-2016 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

#include <map>

using std::map;

#include "PersistentConfig.h"

/*
 * A dumb PersistentConfig class that isn't actually persistent and uses only
 * default values initially, but can be overridden.
 */

class PersistentConfigDefault : public PersistentConfig
{
public:
   virtual bool
   Reload(bool checkForChanges) {
      return true;
   }

   virtual std::string
   GetStringPrivate(Element *element) const {
      map<ConfigId, std::string>::const_iterator it;
      if ((it = mValues.find(element->id)) != mValues.end()) {
         return it->second;
      }
      return element->defaultVal;
   }

   virtual bool
   SetStringPrivate(Element *element, const std::string& val, bool forceUpdate) {
      mValues[element->id] = val;
      return true;
   };

private:
   map<ConfigId, std::string> mValues;
};

PersistentConfig *
getDefaultConfig()
{
   return new PersistentConfigDefault();
}
