/* **********************************************************
 * Copyright (C) 2012 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

#pragma once

class PersistentConfig;
PersistentConfig *getDefaultConfig();
