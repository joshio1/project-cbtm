/* **********************************************************
 * Copyright (C) 2011 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

#include <stdio.h>

#include "PersistentConfig.h"
#include "PersistentConfigDefault.h"
#include "Logging.h"

extern "C" {
#include "poll.h"
}

#include <UnitTest++.h>

// Global for use throughout the test harness
PersistentConfig *gConfig = NULL;

/*
 *------------------------------------------------------------------------------
 * abtest()
 *
 *    Run tests for various AppBlast code.
 *------------------------------------------------------------------------------
 */
int
main(int argc, char **argv)
{
   // Initialize various helper things.
   Poll_InitDefault();
   Log_Init(L"Blast-test");
   gConfig = getDefaultConfig();

   // Set things that are annoying with testing.
   gConfig->SetBool(CONFIG_BLANK_SCREEN_ENABLED, false);
   gConfig->SetBool(CONFIG_RESOLUTION_MATCHING, false);

   int res = UnitTest::RunAllTests();

   Poll_Exit();

   return res;
}
