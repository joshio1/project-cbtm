/* **********************************************************
 * Copyright (C) 2012 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

#pragma once

#include <string>
#include <UnitTest++.h>

class PersistentConfig;
extern PersistentConfig *gConfig;

/*
 * Note: These new test functions/macros were taken from the UnitTest++ headers
 * and modified to add message parameters.
 */

template< typename Expected, typename Actual >
void CheckEqualMsg(UnitTest::TestResults& results, Expected const& expected, Actual const& actual, UnitTest::TestDetails const& details, std::string msg)
{
    if (!(expected == actual))
    {
        UnitTest::MemoryOutStream stream;
        stream << "Expected " << expected << " but was " << actual << " (" << msg << ")";

        results.OnTestFailure(details, stream.GetText());
    }
}

template< typename Value >
void CheckMsg(UnitTest::TestResults& results, Value const value, UnitTest::TestDetails const& details, std::string msg)
{
    if (!UnitTest::Check(value))
    {
        UnitTest::MemoryOutStream stream;
        stream << "Check failed: "<< msg;

        results.OnTestFailure(details, stream.GetText());
    }
}

#define CHECK_MSG(value, msg) \
    do \
    { \
        try { \
            CheckMsg(*UnitTest::CurrentTest::Results(), value, UnitTest::TestDetails(*UnitTest::CurrentTest::Details(), __LINE__), msg); \
        } \
        catch (...) { \
            UnitTest::CurrentTest::Results()->OnTestFailure(UnitTest::TestDetails(*UnitTest::CurrentTest::Details(), __LINE__), \
                    "Unhandled exception in CHECK(" #value ")"); \
        } \
    } while (0)

#define CHECK_EQUAL_MSG(expected, actual, msg) \
    do \
    { \
        try { \
            CheckEqualMsg(*UnitTest::CurrentTest::Results(), expected, actual, UnitTest::TestDetails(*UnitTest::CurrentTest::Details(), __LINE__), msg); \
        } \
        catch (...) { \
            UnitTest::CurrentTest::Results()->OnTestFailure(UnitTest::TestDetails(*UnitTest::CurrentTest::Details(), __LINE__), \
                    "Unhandled exception in CHECK_EQUAL(" #expected ", " #actual ")"); \
        } \
    } while (0)
