/* **********************************************************
 * Copyright (C) 2011 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

#include <Windows.h>
#include <vector>
#include <UnitTest++.h>
#include "appBlastUtil.h"

using std::string;
using std::vector;
using AbUtil::ParseKeyValuePairs;
using AbUtil::ParseURLIntoKeyValuePairs;
using AbUtil::ParseUrlPathPrefix;
using AbUtil::URLEncode;

SUITE(AbUtilTests) {
TEST(URLEncode) {
   CHECK("%26" == AbUtil::URLEncode("&"));
}

TEST(WhackyUrlChars)
{
   string whacky = "!@#$%^&*()-_=+[{]}\\|;:'\",<.>/?";
   string url = "http://localhost?whacky=" + URLEncode(whacky);

   vector<KeyValuePair> params;
   ParseURLIntoKeyValuePairs(url, params);
   CHECK(params.size() == 1);
   CHECK(params[0].value == whacky);
}

TEST(ParseKeyValuePairs) {
   vector<KeyValuePair> test, res, empty;
   res.clear();
   CHECK(res == empty);
   ParseKeyValuePairs("", res);
   CHECK(res == empty);

   res.clear();
   ParseKeyValuePairs("=", res);
   //CHECK(res == empty);

   ParseKeyValuePairs("asdf", res);
   //CHECK(res == empty);

   ParseKeyValuePairs("?", res);
   //CHECK(res == empty);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", ""));
   ParseKeyValuePairs("key=", res);
   CHECK(res == test);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", " "));
   ParseKeyValuePairs("key= ", res);
   CHECK(res == test);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", "value"));
   ParseKeyValuePairs("key=value", res);
   CHECK(res == test);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", "value"));
   test.push_back(KeyValuePair("key2", "value2"));
   ParseKeyValuePairs("key=value&key2=value2", res);
   CHECK(res == test);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", "value"));
   test.push_back(KeyValuePair("key2", ""));
   test.push_back(KeyValuePair("key3", "value3"));
   ParseKeyValuePairs("key=value&key2=&key3=value3", res);
   CHECK(res == test);
}

TEST(ParseURLIntoKeyValuePairs) {
   vector<KeyValuePair> test, res, empty;

   res.clear();
   CHECK(res == empty);
   ParseURLIntoKeyValuePairs("http://www.test.com/", res);
   CHECK(res == empty);

   res.clear();
   ParseURLIntoKeyValuePairs("http://www.test.com/?", res);
   CHECK(res == empty);

   res.clear();
   ParseURLIntoKeyValuePairs("http://www.test.com/? ", res);
   //CHECK(res == empty);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", ""));
   ParseURLIntoKeyValuePairs("http://www.test.com/?key=", res);
   CHECK(res == test);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", ""));
   ParseURLIntoKeyValuePairs("http://www.test.com/?key= ", res);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", "value"));
   ParseURLIntoKeyValuePairs("http://www.test.com?key=value", res);
   CHECK(res == test);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", "value"));
   ParseURLIntoKeyValuePairs("http://www.test.com/?key=value", res);
   CHECK(res == test);

   res.clear(); test.clear();
   test.push_back(KeyValuePair("key", "value"));
   test.push_back(KeyValuePair("key2", "value2"));
   ParseURLIntoKeyValuePairs("http://www.test.com/?key=value&key2=value2", res);
   CHECK(res == test);
}

TEST(ParseUrlPathPrefix) {
   string token, path;

   // Degenerate cases
   token = path = "";
   CHECK(!ParseUrlPathPrefix("", "", token, path));
   CHECK("" == token); CHECK("" == path);

   token = path = "";
   CHECK(!ParseUrlPathPrefix("a", "", token, path));
   CHECK("" == token); CHECK("" == path);

   token = path = "";
   CHECK(!ParseUrlPathPrefix("/", "", token, path));
   CHECK("" == token); CHECK("" == path);

   token = path = "";
   CHECK(!ParseUrlPathPrefix("a", "/r/", token, path));
   CHECK("" == token); CHECK("" == path);

   token = path = "";
   CHECK(!ParseUrlPathPrefix("/r/", "/r/", token, path));
   CHECK("" == token); CHECK("" == path);

   token = path = "";
   CHECK(!ParseUrlPathPrefix("/r//", "/r/", token, path));
   CHECK("" == token); CHECK("" == path);

   token = path = "";
   CHECK(!ParseUrlPathPrefix("/r//path", "/r/", token, path));
   CHECK("" == token); CHECK("" == path);

   token = path = "";
   CHECK(!ParseUrlPathPrefix("/r/ab/path", "/d/", token, path));
   CHECK("" == token); CHECK("" == path);


   // Positive cases
   token = path = "";
   CHECK(ParseUrlPathPrefix("/r/A6BF54DA-7FA3-4AA8-ACD4-C8CF14734CDA/", "/r/", token, path));
   CHECK("A6BF54DA-7FA3-4AA8-ACD4-C8CF14734CDA" == token); CHECK("/" == path);

   token = path = "";
   CHECK(ParseUrlPathPrefix("/d/A6BF54DA-7FA3-4AA8-ACD4-C8CF14734CDA/path", "/d/", token, path));
   CHECK("A6BF54DA-7FA3-4AA8-ACD4-C8CF14734CDA" == token); CHECK("/path" == path);

   token = path = "";
   CHECK(ParseUrlPathPrefix("/r/a/path", "/r/", token, path));
   CHECK("a" == token); CHECK("/path" == path);

   token = path = "";
   CHECK(ParseUrlPathPrefix("/r/ab/path", "/r/", token, path));
   CHECK("ab" == token); CHECK("/path" == path);

   token = path = "";
   CHECK(ParseUrlPathPrefix("/r/a/path/to/resource.html", "/r/", token, path));
   CHECK("a" == token); CHECK("/path/to/resource.html" == path);

   token = path = "";
   CHECK(ParseUrlPathPrefix("/r/ab", "/r/", token, path));
   CHECK("ab" == token); CHECK("" == path);
}

TEST(ClientRequest) {
   string absPath, token, requestPath;
   absPath = "/r/A6BF54DA-7FA3-4AA8-ACD4-C8CF14734CDA/?vauth=pgKNXtM9HOCWbrG7FOEmpef8";
}
}
