#!/c/toolchain/win32/python-2.6.1/python.exe

"""
NAME
   genkeyspec.py - generate a keyspec file from a runing Blast session

SYNOPSIS
   genkeyspec.py <host> <port> <keyspec_file>

INPUTS
   host: the host name or IP to grab input grace data from
   keyspec_file: the keyspec filename for output
"""

import sys
import httplib
import socket
import json
import codecs

if __name__ == '__main__':
   if len(sys.argv) != 4:
      print >>sys.stderr, 'Usage: %s <host> <port> <keyspec_file>'
      sys.exit(1)

   host = sys.argv[1]
   port = sys.argv[2]
   keyspecFileName = sys.argv[3]

   conn = httplib.HTTPSConnection(host, port, timeout = 2)
   inputTraceResponse = None

   try:
      conn.request('GET', '/d/1/input-trace/data')
      inputTraceResponse = conn.getresponse()
   except socket.error as e:
      print >>sys.stderr, 'Unable to obtain trace data:', e
      sys.exit(1)

   if inputTraceResponse.status != httplib.OK:
      print >>sys.stderr, 'Unable to obtain trace data:', \
         inputTraceResponse.status, inputTraceResponse.reason
      sys.exit(1)

   inputTraceData = json.load(inputTraceResponse)
   conn.close()

   with codecs.open(keyspecFileName, 'w', 'utf-8') as keyspecFile:
      json.dump(inputTraceData, keyspecFile, ensure_ascii = False,
         separators = (',', ': '), indent = 3, sort_keys = True)

   print 'Keyspec data written to file', keyspecFileName
