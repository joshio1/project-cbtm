/* **********************************************************
 * Copyright (C) 2014-2015 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

#include <string>
#include <fstream>

#include <Windows.h>
#include <stdio.h>
#include <crtdbg.h>
#include <Shlwapi.h>

#include <UnitTest++.h>

#include "abtest.h"
#include "appBlastUtil.h"
#include "KeyboardHandler.h"
#include "KeySpec.h"

using std::vector;
using std::string;
using std::wstring;
using std::ifstream;

vector<wstring> GetKeySpecFilenames();

struct KeyboardLayoutFixture {
   KeyboardLayoutFixture() {
      EN = LoadKeyboardLayout(L"00000409", KLF_ACTIVATE);
      FR = LoadKeyboardLayout(L"0000040C", KLF_ACTIVATE);
      kbHandler = new KeyboardHandler;
   }
   ~KeyboardLayoutFixture() {
      delete kbHandler;
   }

   HKL EN, FR;
   KeyboardHandler *kbHandler;
};

struct KbHelperFixture {
   KbHelperFixture() {
      /* setup to instanciate KeyboardHandler object */
      kbHandler = new KeyboardHandler();
   }
   ~KbHelperFixture() {
      delete kbHandler;
   }

   KeyboardHandler *kbHandler;
};

   // Keep a reference to KeyboardHandler, remove it at the end.

SUITE(KeyboardTests) {
TEST(KeySpecs) {
   // Gather the filenames for all *.keyspec files.
   vector<wstring> keySpecFilenames = GetKeySpecFilenames();
   CHECK_MSG(keySpecFilenames.size() > 0, "No keyspec files found.");

   // Load each keyspec file as a KeySpec structure.
   for(vector<wstring>::const_iterator keySpecFilename = keySpecFilenames.begin();
       keySpecFilename != keySpecFilenames.end();
       ++keySpecFilename) {
      string fileName = AbUtil::WideToChar(*keySpecFilename);
      ifstream keySpecFile(fileName.c_str(), std::ifstream::binary);
      vector<KeySpec> keySpecs;
      string errorMessage;
      if(!KeySpec::FromJson(keySpecFile, keySpecs, errorMessage)) {
         errorMessage = "Parsing of key spec file " + fileName + " failed: " + errorMessage;
         CHECK_MSG(false, errorMessage);
      } else {
         printf("   Running tests for keyspec file '%s'...\n", fileName.c_str());

         // Assert on every KeySpec that was loaded.
         for (vector<KeySpec>::const_iterator keySpec = keySpecs.begin();
              keySpec != keySpecs.end();
              ++keySpec) {
            keySpec->Assert();
         }
      }
   }
   printf("Done testing keyspec files.\n\n");
}


#if 0
// Disabling this test for now: it fails when run in a session
// with no active login.  So it fails when run via Jenkins but not
// for a dev as the dev will have an active login.
TEST_FIXTURE(KbHelperFixture, DownKeys) {
   vector<INPUT> inputs;
   bool downKeys[3];

   // Set up down/up INPUT structures for use later.
   KEYBDINPUT shiftUpKbd = {VK_SHIFT, 42, KEYEVENTF_KEYUP, 0, 0},
              ctrlUpKbd = {VK_CONTROL, 29, KEYEVENTF_KEYUP, 0, 0},
              altUpKbd = {VK_MENU, 56, KEYEVENTF_KEYUP, 0, 0},
              shiftDownKbd = {VK_SHIFT, 42, 0, 0, 0},
              ctrlDownKbd = {VK_CONTROL, 29, 0, 0, 0},
              altDownKbd = {VK_MENU, 56, 0, 0, 0};
   INPUT shiftUp, ctrlUp, altUp, shiftDown, ctrlDown, altDown;
   shiftUp.ki = shiftUpKbd; shiftUp.type = INPUT_KEYBOARD;
   ctrlUp.ki = ctrlUpKbd; ctrlUp.type = INPUT_KEYBOARD;
   altUp.ki = altUpKbd; altUp.type = INPUT_KEYBOARD;
   shiftDown.ki = shiftDownKbd; shiftDown.type = INPUT_KEYBOARD;
   ctrlDown.ki = ctrlDownKbd; ctrlDown.type = INPUT_KEYBOARD;
   altDown.ki = altDownKbd; altDown.type = INPUT_KEYBOARD;

   /*
    * Send Shift, Ctrl, and Alt up keystrokes to ensure they are not pressed
    * for this test.
    */
   inputs.push_back(shiftUp);
   inputs.push_back(ctrlUp);
   inputs.push_back(altUp);
   CHECK(SendInput(inputs.size(), &*inputs.begin(), sizeof(INPUT)) == 3);
   inputs.clear();

   // Verify that Shift, Ctrl, and Alt are not pressed.
   kbHandler->FillDownKeys(downKeys);
   CHECK(!kbHandler->IsKeyDown(VK_SHIFT, downKeys));
   CHECK(!kbHandler->IsKeyDown(VK_CONTROL, downKeys));
   CHECK(!kbHandler->IsKeyDown(VK_MENU, downKeys));

   // Send Shift down keystroke.
   inputs.push_back(shiftDown);
   CHECK(SendInput(inputs.size(), &*inputs.begin(), sizeof(INPUT)) == 1);
   inputs.clear();

   // Verify that Shift is pressed.
   kbHandler->FillDownKeys(downKeys);
   CHECK(kbHandler->IsKeyDown(VK_SHIFT, downKeys));

   // Send Ctrl down keystroke.
   inputs.push_back(ctrlDown);
   CHECK(SendInput(inputs.size(), &*inputs.begin(), sizeof(INPUT)) == 1);
   inputs.clear();

   // Verify that Shift and Ctrl is pressed.
   kbHandler->FillDownKeys(downKeys);
   CHECK(kbHandler->IsKeyDown(VK_SHIFT, downKeys));
   CHECK(kbHandler->IsKeyDown(VK_CONTROL, downKeys));

   // Send Alt down keystroke.
   inputs.push_back(altDown);
   CHECK(SendInput(inputs.size(), &*inputs.begin(), sizeof(INPUT)) == 1);
   inputs.clear();

   // Verify that Shift, Ctrl, and Alt is pressed.
   kbHandler->FillDownKeys(downKeys);
   CHECK(kbHandler->IsKeyDown(VK_SHIFT, downKeys));
   CHECK(kbHandler->IsKeyDown(VK_CONTROL, downKeys));
   CHECK(kbHandler->IsKeyDown(VK_MENU, downKeys));

   /*
    * Send Shift, Ctrl, and Alt up keystrokes to ensure they are not pressed
    * after this test.
    */
   inputs.push_back(shiftUp);
   inputs.push_back(ctrlUp);
   inputs.push_back(altUp);
   CHECK(SendInput(inputs.size(), &*inputs.begin(), sizeof(INPUT)) == 3);
   inputs.clear();
}
#endif

TEST_FIXTURE(KeyboardLayoutFixture, ProcessKeySimple) {
   vector<INPUT> inputs;
   bool downKeys[3] = {0, 0, 0};
   CHECK(kbHandler->ProcessKey('0', false, false, false, downKeys, EN, inputs));
   CHECK(inputs.size() == 1);
   CHECK(inputs[0].ki.wVk == '0');
   CHECK(inputs[0].ki.wScan == 11);
   CHECK(!inputs[0].ki.time);
   CHECK(!inputs[0].ki.dwExtraInfo);
   CHECK(!inputs[0].ki.dwFlags);
}

TEST_FIXTURE(KeyboardLayoutFixture, IgnoreFrenchLeftBracket) {
   vector<INPUT> inputs;
   bool downKeys[3] = {0, 0, 0};
   CHECK(kbHandler->ProcessKey(VK_OEM_6, false, false, false, downKeys, FR, inputs));
   CHECK(inputs.size() == 0);
   CHECK(kbHandler->ProcessKey(VK_OEM_6, false, false, false, downKeys, EN, inputs));
   CHECK(inputs.size() == 1);
}

TEST_FIXTURE(KeyboardLayoutFixture, ProcessWinKey) {
   vector<INPUT> inputs;
   bool downKeys[3] = {0, 0, 0};
   CHECK(kbHandler->ProcessKey(VK_LWIN, false, false, false, downKeys, EN, inputs));
   CHECK(inputs.size() == 1);
   CHECK(inputs[0].ki.wVk == VK_LWIN);
   inputs.clear();
   CHECK(kbHandler->ProcessKey(VK_RWIN, false, false, false, downKeys, EN, inputs));
   CHECK(inputs.size() == 1);
   CHECK(inputs[0].ki.wVk == VK_RWIN);
   inputs.clear();
}

TEST_FIXTURE(KeyboardLayoutFixture, IgnoreAltTabAppMode) {
   vector<INPUT> inputs;
   bool noneDown[3] = {0, 0, 0},
        altDown[3] = {0, 0, 1};
   CHECK(kbHandler->ProcessKey(VK_TAB, false, false, false, noneDown, EN, inputs));
   CHECK(inputs.size() == 1);
   inputs.clear();
   CHECK(kbHandler->ProcessKey(VK_TAB, false, false, true, noneDown, EN, inputs));
   CHECK(inputs.size() == 1);
   inputs.clear();
   CHECK(kbHandler->ProcessKey(VK_TAB, false, false, false, altDown, EN, inputs));
   CHECK(inputs.size() == 1);
   inputs.clear();
   CHECK(kbHandler->ProcessKey(VK_TAB, false, false, true, altDown, EN, inputs));
   CHECK(inputs.size() == 0);
   inputs.clear();
}
}

vector<wstring> GetKeySpecFilenames() {
   HMODULE hMod = GetModuleHandle(NULL);
   TCHAR szModFilename[MAX_PATH];
   HANDLE hFind = INVALID_HANDLE_VALUE;
   WIN32_FIND_DATA ffd;
   vector<wstring> res;

   // Create a wildcard path for all keyspec files.
   if (NULL == hMod) {
      printf("GetModuleHandle failed, error:0x%08lx.\n", GetLastError());
      return vector<wstring>();
   }
   if (!GetModuleFileName(hMod, szModFilename, ARRAYSIZE(szModFilename))) {
      printf("GetModuleFileName failed, error:0x%08lx.\n", GetLastError());
      return vector<wstring>();
   }
   if (!PathRemoveFileSpec(szModFilename)) {
      printf("PathRemoveFileSpec failed.\n");
      return vector<wstring>();
   }
   wstring keySpecsWildcard = wstring(szModFilename) + L"\\*.keyspec";

   // Find the first keyspec file.
   hFind = FindFirstFile(keySpecsWildcard.c_str(), &ffd);
   if (INVALID_HANDLE_VALUE == hFind) {
      // No files were found, just return an empty collection of files.
      printf("FindFirstFile failed, no files found, error:0x%08lx.\n",
             GetLastError());
      return vector<wstring>();
   }

   // Gather all keyspec files.
   do {
      // Exclude directories.
      if (!(ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
         res.push_back(wstring(szModFilename) + L"\\" + wstring(ffd.cFileName));
      }
   } while (FindNextFile(hFind, &ffd));

   if (GetLastError() != ERROR_NO_MORE_FILES) {
      return vector<wstring>();
   }
   FindClose(hFind);
   return res;
}