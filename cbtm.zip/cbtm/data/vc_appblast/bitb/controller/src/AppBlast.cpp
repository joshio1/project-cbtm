/* **********************************************************
 * Copyright (C) 2016-2017 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

/*
 * AppBlast.cpp --
 *
 *    Communicates with AppBlast through AbCtrl DLL.
 */

#include <assert.h>
#include <iostream>
#include <sstream>
#include <Rpc.h>
#include <Rpcdce.h>

// appblast/common
#include "appBlastUtil.h"
#include "consoleState.h"     // for INVALID_TS_SESSION_ID

#include "AppBlast.h"
#include "BitBUtil.h"

static const uint32 BLASTTOKEN_MAX_BYTESIZE = 4096;
static const uint32 IPADDRESS_MAX_BYTESIZE = 64;

static ConnectionStatus *gConnectionStatus = NULL;

const std::string APPBLAST_LOG_NAME = "AppBlast";
#define DEFINE_LOGGER                                                   \
   log4cxx::LoggerPtr LOG = log4cxx::Logger::getLogger(APPBLAST_LOG_NAME)

/* AppBlast-provided shim DLL that talks to AppBlast */
static const std::wstring APPBLAST_CTRL_DLL = L"abctrl.dll";

/* A macro to check NULL pointer */
#define CHECK_POINTER(ptr, isPtrNull)                          \
   if (ptr == NULL) {                                          \
      LOG_ERROR(mLog, "%s is NULL.", L#ptr);                   \
      isPtrNull = true;                                        \
   }

/* The AbCtrl API version used by this agent */
#define ABCTRL_API_VERSION_USED 3


/*
 *----------------------------------------------------------------------------
 * connectCallback --
 *
 *    Function that the AppBlast shim will call whenever a change occurs
 *    to the AppBlast session count (i.e. when an AppBlast session starts
 *    or ends).
 *----------------------------------------------------------------------------
 */

extern "C" void
ConnectCallback(bool connect, char* token)
{
   DEFINE_LOGGER;

   LOG_INFO(LOG, "ConnectCallback received from blast: type:%s, token:%s.",
            connect ? "connect" : "disconnect", token);

   if (gConnectionStatus) {
      gConnectionStatus->SetVAuthStatus(token, connect);
   } else {
      LOG_ERROR(LOG, "gConnectionStatus is not initialized.");
   }
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::AppBlast --
 *
 *    Constructor.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

AppBlast::AppBlast():
   mLog(log4cxx::Logger::getLogger(APPBLAST_LOG_NAME)),
   mAbCtrlLibHandle(NULL),
   mAbCtrlMinVersion(0),
   mAbCtrlMaxVersion(0),
   mFuncTable(),
   mQueryVersion(NULL),
   mQueryInterface(NULL)
{
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::~AppBlast --
 *
 *    Destructor.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

AppBlast::~AppBlast()
{
   Cleanup();
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::Init --
 *
 *    Initialize this class instance. This MUST be called before any other
 *    method. If the instance fails to initialize, delete it.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::Init()
{
   bool success = false;

   /* Don't initialize twice */
   if (IsInitialized()) {
      LOG_WARN(mLog, "AppBlast already initialized.");
      return true;
   }

   /* Initialize gConnectionStatus */
   gConnectionStatus = new ConnectionStatus();
   if (gConnectionStatus == NULL) {
      LOG_ERROR(mLog, "Failed to allocate storage speace for "
                "gConnectionStatus.");
      goto out;
   }

   LOG_INFO(mLog, "Initializing AbCtrl DLL.");

   /* Load the DLL */
   mAbCtrlLibHandle = LoadLibrary(APPBLAST_CTRL_DLL.c_str());
   if (mAbCtrlLibHandle == NULL) {
      LOG_ERROR(mLog, "Failed to load AbCtrl DLL, error:0x%08lx.",
                GetLastError());
      goto out;
   }
   LOG_INFO(mLog, "AbCtrl DLL loaded successfully, module:0x%04lx.",
            mAbCtrlLibHandle);

   /* Locate functions inside the DLL */
   mQueryVersion =
      (AbCtrlQueryVersion) GetProcAddress(mAbCtrlLibHandle,
         "AppBlast_QueryVersion");
   mQueryInterface =
      (AbCtrlQueryInterface) GetProcAddress(mAbCtrlLibHandle,
         "AppBlast_QueryInterface");

   if (!mQueryVersion || !mQueryInterface) {
      LOG_ERROR(mLog, "Failed to locate functions in AbCtrl DLL, error:"
                "0x%08lx.", GetLastError());
      goto out;
   }

   LOG_INFO(mLog, "AbCtrl DLL functions loaded successfully.");

   /* Query AbCtrl DLL min, and max versions */
   DWORD err = (*mQueryVersion)(&mAbCtrlMinVersion, &mAbCtrlMaxVersion);
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "AppBlast_QueryVersion failed, error:0x%08lx.", err);
      goto out;
   }

   uint64 version = ABCTRL_API_VERSION_USED;
   if (version < mAbCtrlMinVersion || version > mAbCtrlMaxVersion) {
      LOG_ERROR(mLog, "AbCtrl API version %u is incompatible (Min supported "
                "version: %u, Max supported version: %u).", version,
                mAbCtrlMinVersion, mAbCtrlMaxVersion);
      goto out;
   }

   err = (*mQueryInterface)(version, (void*)&mFuncTable, sizeof(mFuncTable));
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "AppBlast_QueryInterface failed, error:0x%08lx.", err);
      goto out;
   }

   LOG_INFO(mLog, "AppBlast_QueryInterface succeeded.");

   bool isFuncPtrNull = false;
   CHECK_POINTER(mFuncTable.v1.Initialize, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.Cleanup, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.IsInstalled, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.IsInUse, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.IsRunning, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.Start, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.Stop, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.SetConnectCallback, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.PrepareSessionEx, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.TerminateSessionEx, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.GetStatus, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v1.GetIpAndPort, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v2.PrepareSession, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v2.SetConnectCallback, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v3.ShadowPrepareSession, isFuncPtrNull)
   CHECK_POINTER(mFuncTable.v3.AllowInput, isFuncPtrNull)

   if (isFuncPtrNull) {
      LOG_ERROR(mLog, "Found NULL function pointer(s) in the function table.");
      goto out;
   }

   /* Initialize the DLL */
   err = mFuncTable.v1.Initialize();
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "AbCtrl_Initialize failed, error:0x%08lx.", err);
      if (err == ERROR_ACCESS_DENIED) {
         LOG_ERROR(mLog, "Error:ERROR_ACCESS_DENIED. Both BitB and View Agent "
                   "cannot run at the same time. Is View Agent running?");
      }
      goto out;
   }

   LOG_INFO(mLog, "AbCtrl DLL initialized successfully.");\

   /* Register our connection callback */
   err = mFuncTable.v1.SetConnectCallback((SessionConnectCb)ConnectCallback);
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "Session callback not registered, error:0x%08lx.", err);
      goto out;
   }

   LOG_INFO(mLog, "Session callback registered.");

   /* Print some useful info */
   LOG_INFO(mLog, "AbCtrl DLL Installed: %s.", IsInstalled() ? "Yes" : "No");
   LOG_INFO(mLog, "AbCtrl DLL Running: %s.", IsRunning() ? "Yes" : "No");
   success = true;

out:
   if (!success) {
      Cleanup();
   }

   return success;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::PrepareSession --
 *
 *    Asks AppBlast to generate a new session. On success, a new token value
 *    is generated. This function receives a token, ip, and port number
 *    associated with the session.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::PrepareSession()
{
   if (!mSessionsData.empty() && !mSessionsData.front().IsEmpty()) {
      LOG_ERROR(mLog, "Session has been prepared/initialized previously.");
      return false;
   }

   char token[BLASTTOKEN_MAX_BYTESIZE] = { 0 };
   char ip[IPADDRESS_MAX_BYTESIZE] = { 0 };
   int port = 0;

   DWORD wtsSessionID = AbUtil::GetUserOrConsoleSessionId();
   if (wtsSessionID == INVALID_TS_SESSION_ID) {
      LOG_ERROR(mLog, "Unable to retrieve current WTSSessionID.");
      return false;
   }
   LOG_DEBUG(mLog, "Running in WTSSessionID:%lu.", wtsSessionID);

   /*
    * TODO: v1.PrepareSessionEx is deprecated, and v2.PrepareSession is
    * used in production code. For backward compatibility, there should
    * be cases for both APIs, and v2.PrepareSession should be prioritized.
    */
   DWORD err = mFuncTable.v1.PrepareSessionEx(wtsSessionID,
                                              true,
                                              token,
                                              sizeof(token),
                                              ip,
                                              sizeof(ip),
                                              &port);
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "Failed to prepare the session, error:0x%08lx.", err);
      return false;
   }

   SessionData sessionData;
   sessionData.ip = ip;
   sessionData.port = BitBUtil::to_string(port);
   sessionData.token = ParseJson(token, "a");
   if (sessionData.ip.empty()) {
      LOG_ERROR(mLog, "Failed to prepare the session, empty ip.");
      return false;
   }
   if (sessionData.port.empty()) {
      LOG_ERROR(mLog, "Failed to prepare the session, empty port.");
      return false;
   }
   if (sessionData.token.empty()) {
      LOG_ERROR(mLog, "Failed to prepare the session, empty token. "
                "Token response:%s.", token);
      return false;
   }

   UUID uuid;
   if (UuidCreate(&uuid) != RPC_S_OK) {
      LOG_ERROR(mLog, "An error occurred in UuidCreate.");
      return false;
   }

   char *guid;
   if (UuidToStringA(&uuid, (RPC_CSTR*)&guid) != RPC_S_OK) {
      LOG_ERROR(mLog, "An error occurred in UuidToString.");
      return false;
   }

   sessionData.guid = guid;
   RpcStringFreeA((RPC_CSTR*)&guid);

   if (mSessionsData.empty()) {
      mSessionsData.push_back(sessionData);
   } else {
      mSessionsData[PRIMARY_CLIENT_INDEX] = sessionData;
   }

   LOG_INFO(mLog, "Session guid:%s, token:%s, ip:%s, port:%s.",
            sessionData.guid.c_str(),
            sessionData.token.c_str(),
            sessionData.ip.c_str(),
            sessionData.port.c_str());

   gConnectionStatus->AddNewVAuth(sessionData.token);

   return true;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::TerminateSession --
 *
 *    Asks AppBlast to terminate a session.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::TerminateSession(const VDPConnectionResult reason,   // IN
                           unsigned int clientIndex)           // IN
{
   LOG_INFO(mLog, "Terminating shadow session, reason:%d, clientIndex:%u.",
            reason, clientIndex);

   if (mSessionsData.size() <= clientIndex) {
      LOG_ERROR(mLog, "No SessionData for client #%u, mSessionsData size:%u.",
                clientIndex, mSessionsData.size());
      return false;
   }

   SessionData sessionData = mSessionsData[clientIndex];

   if (sessionData.IsEmpty()) {
      LOG_ERROR(mLog, "Session data empty.");
      return false;
   }
   LOG_INFO(mLog, "Calling TerminateSession with reason:%d, using sessionData "
            "vAuth:%s, guid:%s, ip:%s, port:%s.",
            reason,
            sessionData.token.c_str(),
            sessionData.guid.c_str(),
            sessionData.ip.c_str(),
            sessionData.port.c_str());

   if (!CallTerminateSession(sessionData.token, reason)) {
      LOG_ERROR(mLog, "Terminate session call failed, clientIndex:%u, "
                "token:%s.", clientIndex, sessionData.token.c_str());
      return false;
   }

   LOG_INFO(mLog, "Terminating shadow session succeeded, reason:%d, "
            "clientIndex:%u.", reason, clientIndex);
   return true;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::CallTerminateSession --
 *
 *    Call AppBlast to terminate a session.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::CallTerminateSession(const std::string &token,             // IN
                               const VDPConnectionResult &reason)    // IN
{
   if (token.empty()) {
      LOG_ERROR(mLog, "Token is empty.");
      return false;
   }

   DWORD err = mFuncTable.v1.TerminateSessionEx(token.c_str(), reason);
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "Failed to terminate the session for token:%s, "
                "error:0x%08lx.", token.c_str(), err);
      return false;
   }

   return true;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::IsInitialized --
 *
 *    Checks whether this class instance is initialized.
 *
 * Results:
 *    true if initialized, false otherwise.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::IsInitialized() const
{
   bool init = (mAbCtrlLibHandle != NULL);
   return init;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::IsInstalled --
 *
 *    Checks whether AppBlast is installed.
 *
 * Results:
 *    true if installed, false otherwise.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::IsInstalled() const
{
   if (!IsInitialized()) {
      LOG_ERROR(mLog, "AbCtrl DLL not initialized.");
      assert(false);
      return false;
   }

   bool installed = false;
   DWORD err = mFuncTable.v1.IsInstalled(&installed);
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "Failed to determine install state, error:0x%08lx.",
                err);
      return false;
   }

   return installed;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::IsRunning --
 *
 *    Checks whether AppBlast is installed and running.
 *
 * Results:
 *    true if installed and running, false otherwise.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::IsRunning() const
{
   if (!IsInitialized()) {
      LOG_ERROR(mLog, "AbCtrl DLL not initialized.");
      assert(false);
      return false;
   }

   if (!IsInstalled()) {
      LOG_ERROR(mLog, "AbCtrl DLL not installed -> not running.");
      return false;
   }

   bool running;
   DWORD err = mFuncTable.v1.IsRunning(&running);
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "Failed to determine running state, error:0x%08lx.",
                err);
      return false;
   }

   return running;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::IsInUse --
 *
 *    Checks whether AppBlast is in use.
 *
 * Results:
 *    true if AppBlast is in use, false otherwise.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::IsInUse() const
{
   if (!IsRunning()) {
      LOG_ERROR(mLog, "AppBlast is not running.");
      return false;
   }

   bool isInUse;
   DWORD err = mFuncTable.v1.IsInUse(&isInUse);
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "Failed to determine IsInUse state, error:0x%08lx.",
                err);
      return false;
   }

   LOG_DEBUG(mLog, "AppBlast session is %sin use.", (isInUse ? "" : "not "));

   return isInUse;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::AllowInput --
 *
 *    Mute/unmute the input control of the session associated with the given
 *    vAuth.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::AllowInput(const unsigned int &clientIndex,    // IN
                     const bool &allowInput)             // IN
{
   SessionData sessionData;
   if (!GetSessionData(clientIndex, sessionData)) {
      LOG_ERROR(mLog, "Failed to get session data, clientIndex:%u, "
                "allowInput:%s.", clientIndex, allowInput ? "true" : "false");
      return false;
   }

   DWORD err = mFuncTable.v3.AllowInput(sessionData.token.c_str(), allowInput);
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "Failed to mute/unmute the input control, "
                "clientIndex:%u, allowInput:%s, error:0x%08lx.", clientIndex,
                allowInput ? "true" : "false", err);
      return false;
   }

   LOG_DEBUG(mLog, "Input control %s on clientIndex %u.",
             allowInput ? "unmuted" : "muted", clientIndex);

   return true;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::ShadowPrepareSession --
 *
 *    Generate a vAuth for shadow session.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::ShadowPrepareSession()
{
   /*
    * Skip testing if mSessionsData.empty(). Let the actual AbCtrl API
    * verify that and return an appropriate error.
    */

   if (mSessionsData.empty()) {
      LOG_WARN(mLog, "Primary session data missing.");
   }

   DWORD wtsSessionID = AbUtil::GetUserOrConsoleSessionId();
   if (wtsSessionID == INVALID_TS_SESSION_ID) {
      LOG_ERROR(mLog, "Unable to retrieve current WTSSessionID.");
      return false;
   }
   LOG_DEBUG(mLog, "Running in WTSSessionID:%lu.", wtsSessionID);

   char token[BLASTTOKEN_MAX_BYTESIZE] = { 0 };
   int port = -1;

   DWORD err = mFuncTable.v3.ShadowPrepareSession(wtsSessionID,
                                                  token,
                                                  sizeof(token),
                                                  "0.0.0.0",
                                                  "",
                                                  &port,
                                                  true);
   if (err != ERROR_SUCCESS) {
      LOG_ERROR(mLog, "Failed to prepare the session, error:0x%08lx.", err);
      return false;
   }

   SessionData sessionData;
   sessionData.ip = mSessionsData.front().ip;
   sessionData.port = BitBUtil::to_string(port);
   sessionData.token = ParseJson(token, "a");
   if (sessionData.token.empty()) {
      LOG_ERROR(mLog, "Failed to prepare the session, empty token."
                "Token response:%s.", token);
      return false;
   }

   UUID uuid;
   if (UuidCreate(&uuid) != RPC_S_OK) {
      LOG_ERROR(mLog, "An error occurred in UuidCreate.");
      return false;
   }

   char *guid;
   if (UuidToStringA(&uuid, (RPC_CSTR*)&guid) != RPC_S_OK) {
      LOG_ERROR(mLog, "An error occurred in UuidToString.");
      return false;
   }

   sessionData.guid = guid;
   RpcStringFreeA((RPC_CSTR*)&guid);

   LOG_INFO(mLog, "Created shadowVAuth:%s Session guid:%s, ip:%s, port:%s for "
            "vAuth:%s.",
            sessionData.token.c_str(),
            sessionData.guid.c_str(),
            sessionData.ip.c_str(),
            sessionData.port.c_str(),
            mSessionsData.front().token.c_str());

   mSessionsData.push_back(sessionData);
   LOG_INFO(mLog, "Created a new shadowVAuth, shadowSessionDataCount:%d.",
            mSessionsData.size());

   gConnectionStatus->AddNewVAuth(sessionData.token);

   return true;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::ResetSessionData --
 *
 *    Reset session data for requested client index.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::ResetSessionData(unsigned int clientIndex)     // IN
{
   if (mSessionsData.size() <= clientIndex) {
      LOG_ERROR(mLog, "No SessionData for client #%u, mSessionsData size:%u.",
                clientIndex, mSessionsData.size());
      return false;
   }

   LOG_DEBUG(mLog, "Resetting shadow session data client #%u.", clientIndex);
   mSessionsData[clientIndex].ResetSessionData();

   return true;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::GetSessionData --
 *
 *    Retrieve session data for requested client index.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::GetSessionData(unsigned int clientIndex,     // IN
                         SessionData &sessionData)     // OUT
{
   if (mSessionsData.size() <= clientIndex) {
      LOG_ERROR(mLog, "No SessionData for client #%u, mSessionsData size:%u.",
                clientIndex, mSessionsData.size());
      return false;
   }

   sessionData = mSessionsData[clientIndex];
   return true;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::GetVAuthConnectionStatus --
 *
 *    Get vAuth connection status.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlast::GetVAuthConnectionStatus(const std::string &vAuth,      // IN
   ConnectionStatus::VAUTHSTATUS &status)                         // OUT
{
   if (!gConnectionStatus) {
      LOG_ERROR(mLog, "gConnectionStatus is not initialized.");
      return false;
   }

   return gConnectionStatus->GetVAuthStatus(vAuth, status);
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::Cleanup --
 *
 *    Uninitialize member variables.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

void
AppBlast::Cleanup()
{
   while (!mSessionsData.empty()) {
      SessionData sessionData = mSessionsData.back();
      if (!sessionData.IsEmpty()) {
         LOG_INFO(mLog, "Terminating pending session, vAuth:%s",
                  sessionData.token.c_str());
         if (!CallTerminateSession(sessionData.token,
                                   VDPCONNECT_SERVER_ERROR)) {
            LOG_WARN(mLog, "Failed to terminate session, vAuth:%s",
                     sessionData.token.c_str());
         }
      }

      mSessionsData.pop_back();
   }

   if (IsInitialized()) {
      if (*mFuncTable.v1.Cleanup != NULL) {
         mFuncTable.v1.Cleanup();
      }

      if (FreeLibrary(mAbCtrlLibHandle)) {
         LOG_INFO(mLog, "AbCtrl DLL is unloaded.");
      } else {
         LOG_ERROR(mLog, "Failed to unloading AbCtrl DLL, error:0x%08lx",
                   GetLastError());
      }
      mAbCtrlLibHandle = NULL;
   } else {
      LOG_WARN(mLog, "AppBlast is not initialized.");
   }

   mAbCtrlMinVersion = 0;
   mAbCtrlMaxVersion = 0;
   memset(&mFuncTable, 0, sizeof(mFuncTable));

   mQueryVersion   = NULL;
   mQueryInterface = NULL;

   if (gConnectionStatus) {
      delete gConnectionStatus;
      gConnectionStatus = NULL;
   } else {
      LOG_WARN(mLog, "gConnectionStatus is not initialized.");
   }
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlast::ParseJson --
 *
 *    This function returns value associated with the key.
 *
 * Results:
 *    Returns value associated with the key, or an empty string if key is not
 *    found.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::string
AppBlast::ParseJson(const std::string& json,    // IN
                    const std::string& jsonKey) // IN
{
   size_t p1 = json.find(jsonKey);

   if (p1 == std::string::npos) {
      LOG_ERROR(mLog, "JSON key %s not found.", jsonKey.c_str());
      return "";
   }

   size_t p2 = json.find("\"", p1 + jsonKey.size() + 2) + 1;
   size_t p3 = json.find("\"", p2 + 1);

   return json.substr(p2, p3 - p2);
}