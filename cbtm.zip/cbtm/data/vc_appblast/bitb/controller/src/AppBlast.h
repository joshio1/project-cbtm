/* **********************************************************
 * Copyright (C) 2016-2017 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

/*
 * AppBlast.h --
 *
 *    Communicates with AppBlast through AbCtrl DLL.
 */

#pragma once

#include <string>
#include <vector>
#include <Windows.h>

#include "ConnectionStatus.h"
#include "IAbCtrl.h"
#include "Logging.h"
#include "SessionData.h"

enum VDPConnectionResult;

class AppBlast
{
public:
   AppBlast();
   virtual ~AppBlast();

   bool Init();
   bool PrepareSession();
   bool ShadowPrepareSession();
   bool TerminateSession(const VDPConnectionResult reason,
                         unsigned int clientIndex);

   bool IsInitialized() const;
   bool IsInstalled() const;
   bool IsRunning() const;
   bool IsInUse() const;

   bool AllowInput(const unsigned int &clientIndex,
                   const bool &allowInput);

   bool ResetSessionData(unsigned int clientIndex);
   bool GetSessionData(unsigned int clientIndex,
                       SessionData &sessionData);
   std::vector <SessionData> GetSessionsData() {
      return mSessionsData;
   }

   bool GetVAuthConnectionStatus(const std::string &vAuth,
                                 ConnectionStatus::VAUTHSTATUS &status);

private:
   bool AppBlast::CallTerminateSession(const std::string &token,
                                       const VDPConnectionResult &reason);
   void Cleanup();
   std::string ParseJson(const std::string& json,
                         const std::string& jsonKey);

   log4cxx::LoggerPtr mLog;

   HMODULE mAbCtrlLibHandle;

   std::vector <SessionData> mSessionsData;

   uint64 mAbCtrlMinVersion;
   uint64 mAbCtrlMaxVersion;
   AbCtrl_API mFuncTable;

   AbCtrlQueryVersion mQueryVersion;
   AbCtrlQueryInterface mQueryInterface;
};