/* **********************************************************
 * Copyright (C) 2016-2017 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

/*
 * BitB.cpp --
 *
 */
#include <conio.h>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <windows.h>

#pragma warning (push)
#pragma warning (disable: 4231)
#include "log4cxx/consoleappender.h"
#include "log4cxx/patternlayout.h"
#pragma warning (pop)

extern "C" {
#include "poll.h"
}

// appblast/common
#include "AppBlastUtil.h"
#include "Logging.h"
#include "PersistentConfig.h"

// appblast/bitb/controller/src
#include "AppBlast.h"
#include "BitBOption.h"
#include "JsonHelper.h"
#include "TestCase.h"
#include "TestCaseData.h"
#include "TestReport.h"
#include "TestReportData.h"

using log4cxx::AppenderPtr;
using log4cxx::ConsoleAppender;
using log4cxx::Logger;
using log4cxx::LoggerPtr;
using log4cxx::PatternLayout;

const std::string MAIN_LOG_NAME = "main";
#define DEFINE_LOGGER                                                   \
   log4cxx::LoggerPtr LOG = log4cxx::Logger::getLogger(MAIN_LOG_NAME)

bool AppBlastAcceptHttpsMode();
bool ExecuteTestCases(BitBOption bitBOption,
                      std::string testFile,
                      TestReport &testReport);
void ExtractBrowserLog(BitBOption &bitBOption, std::string testName);
bool GenerateReports(TestReport testReport);
std::wstring GetTimeStringW();
void LogToConsole();
bool ParseCommandLine(int argc, char *argv[],
                      BitBOption &opt);
void PrintUsage();
bool VerifyBlastConfig();


int
main(int argc, char* argv[])
{
   DEFINE_LOGGER;
   Log_Init(L"BitB");
   LogToConsole();

   LOG_INFO(LOG, "BitB start.");

   if (!AbUtil::SetupCoreDump()) {
      LOG_FATAL(LOG, "Failed to setup CoreDump. Exiting...");
      return 1;
   }

   int err = -1;
   BitBOption opt;
   std::list<std::string> testFiles;
   std::list<std::string>::iterator it;

   if (!ParseCommandLine(argc, argv, opt)) {
      LOG_ERROR(LOG, "Error parsing command line.");
      goto cleanup;
   }

   if (opt.IsAppBlastAcceptHttpsMode()) {
      LOG_INFO(LOG, "BitB is running to setup AppBlast in listening https "
               "connection mode.");
      if (AppBlastAcceptHttpsMode()) {
         return 0;
      } else {
         return 1;
      }
   }

   if (!VerifyBlastConfig()) {
      LOG_FATAL(LOG, "Blast setting is not compatible with BitB. Exiting...");
      return 1;
   }

   if (!opt.Validate()) {
      PrintUsage();
      goto cleanup;
   }

   testFiles = opt.GetTestFiles();

   for (it = testFiles.begin(); it != testFiles.end(); ++it) {
      std::string testFile = *it;
      TestReport testReport;

      LOG_INFO(LOG, "Processing file:%s.", testFile.c_str());

      if (!testReport.SetTestFileName(opt.GetTestFileName(testFile))) {
         LOG_ERROR(LOG, "Failed to set test file name, testFile:%s.",
                   testFile.c_str());
         goto cleanup;
      }

      if (!ExecuteTestCases(opt, testFile, testReport)) {
         LOG_ERROR(LOG, "Failed to execute test cases, testFile:%s.",
                   testFile.c_str());
      }

      if (!GenerateReports(testReport)) {
         LOG_ERROR(LOG, "BitB report generation failed, testFile:%s.",
                   testFile.c_str());
         goto cleanup;
      }
   }
   err = 0;

cleanup:
   LOG_INFO(LOG, "BitB exit.");
   Log_Cleanup();

   return err;
}


/*
 *----------------------------------------------------------------------------
 *
 * AppBlastAcceptHttpsMode --
 *
 *    Put appblast in "https listening" mode such that the browser can connect
 *    to it, retrieve and give user an opportunity to accept the SSL
 *    certificate.
 *    This is necessary for self-signed certificate, which otherwise will cause
 *    browser to reject wss connection.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
AppBlastAcceptHttpsMode()
{
   DEFINE_LOGGER;

   std::string blastURL;
   bool exitCode = false;
   SessionData sd;
   AppBlast *appBlast = new AppBlast();
   if (appBlast == NULL) {
      LOG_ERROR(LOG, "Out of memory when creating AppBlast.");
      goto Exit;
   }
   if (!appBlast->Init()) {
      LOG_ERROR(LOG, "Failed to initialize AppBlast.");
      goto Exit;
   }

   if (!appBlast->PrepareSession()) {
      LOG_ERROR(LOG, "Failed to prepare session for AppBlast.");
      goto Exit;
   }

   if (appBlast->GetSessionsData().empty()) {
      LOG_ERROR(LOG, "Primary session data missing.");
      return false;
   }

   sd = appBlast->GetSessionsData().front();
   if (sd.ip.empty() || sd.token.empty()) {
      LOG_ERROR(LOG, "Unable to retrieve connection data from AppBlast.");
      goto Exit;
   }

   blastURL = "//" + sd.ip + ":" + sd.port + "/d/" + sd.guid
      + "/?vauth=" + sd.token;
   LOG_INFO(LOG, "URL: %s", blastURL.c_str());

   LOG_INFO(LOG, "AppBlast is now in listening Https mode.")
   LOG_INFO(LOG, "Point browser to: https://%s:22443 to accept appblast's "
            "SSL certificate.", sd.ip.c_str());
   LOG_INFO(LOG, "AppBlast will be in this mode for ~2 min.");

   exitCode = true;

Exit:
   if (appBlast) {
      delete appBlast;
      appBlast = NULL;
   }

   return exitCode;
}


/*
 *----------------------------------------------------------------------------
 *
 * ExecuteTestCases --
 *
 *    Execute test cases.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
ExecuteTestCases(BitBOption bitBOption,      // IN
                 std::string testFile,       // IN
                 TestReport &testReport)     // OUT
{
   DEFINE_LOGGER;

   bool result = true;
   std::list<TestCaseData> testCases;

   // Log the options into log file.
   bitBOption.LogOptions();

   if (JsonHelper::ParseTestCases(testFile, testCases)) {

      LOG_DEBUG(LOG, "Initializing Poll system, threadId:0x%04lx.",
                GetCurrentThreadId());
      Poll_InitDefault();

      std::list<TestCaseData>::iterator tcIt;
      for (tcIt = testCases.begin(); tcIt != testCases.end(); ++tcIt) {
         TestCaseData testCaseData = *tcIt;
         for (unsigned int i = 0; i < testCaseData.loop; ++i) {
            LOG_INFO(LOG, "Processing TestCase:%s (%u/%u).",
                     testCaseData.name.c_str(), i+1, testCaseData.loop);

            TestCase testCase(bitBOption, testCaseData);
            bool testCaseSkipped = false;
            if (!testCase.Init(testCaseSkipped)) {
               if (!testCaseSkipped) {
                  result = false;
                  LOG_ERROR(LOG, "Initializing test case failed.");
               }
               testReport.AddTestCaseReport(testCase.GetTestCaseReport());
               continue;
            }

            if (!testCase.Execute()) {
               result = false;
               LOG_ERROR(LOG, "Running test case failed.");
               testReport.AddTestCaseReport(testCase.GetTestCaseReport());
               ExtractBrowserLog(bitBOption, testCaseData.name);
               continue;
            }

            ExtractBrowserLog(bitBOption, testCaseData.name);

            testReport.AddTestCaseReport(testCase.GetTestCaseReport());
            LOG_INFO(LOG, "Processing TestCase:%s completed.",
               testCaseData.name.c_str());
         }
      }

      LOG_DEBUG(LOG, "Exiting Poll system, threadId:0x%04lx...",
                GetCurrentThreadId());
      Poll_Exit();
   }

   return result;
}


/*
 *----------------------------------------------------------------------------
 *
 * GenerateReports --
 *
 *    Generate test case reports.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
GenerateReports(TestReport testReport)    // IN
{
   DEFINE_LOGGER;

   bool result = true;

   if (!testReport.GenerateConsoleReport()) {
      LOG_ERROR(LOG, "Failed to generate console report.");
      result = false;
   }

   std::wstring appDataDir;
   if (!AbUtil::GetCommonAppDataDir(appDataDir)) {
      LOG_ERROR(LOG, "Failed to get CommonAppDataDir.");
      return false;
   }

   std::string fileName = testReport.GetTestFileName();
   std::wstring wsFileName(fileName.begin(), fileName.end());
   std::wstring textFilename = appDataDir + L"\\" + wsFileName +
                               L"-BitB-Report.txt";
   if (!testReport.GenerateTextReport(textFilename)) {
      LOG_ERROR(LOG, "Failed to generate text report.");
      result = false;
   }

   std::wstring xmlFilename = appDataDir + L"\\" + wsFileName +
                              L"-BitB-Report.xml";
   if (!testReport.GenerateJenkinsXmlReport(xmlFilename)) {
      LOG_ERROR(LOG, "Failed to generate jenkins xml report.");
      result = false;
   }

   return result;
}


/*
 *----------------------------------------------------------------------------
 *
 * LogToConsole --
 *
 *    Log to console as well.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

void
LogToConsole()
{
#define CONSOLE_LAYOUT L"%d 0x%.4t [%-5p] %c::%M: %m\r\n"
   std::wstring consolePatternLayout = CONSOLE_LAYOUT;

   LoggerPtr log = Logger::getRootLogger();
   AppenderPtr consoleAppender =
      new ConsoleAppender(new PatternLayout(consolePatternLayout));

   log->addAppender(consoleAppender);
}


/*
 *----------------------------------------------------------------------------
 *
 * ParseCommandLine --
 *
 *    Parse command line arguments.
 *
 * Results:
 *    true on success, false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
ParseCommandLine(int argc,          // IN
                 char *argv[],      // IN
                 BitBOption &opt)   // IN
{
   DEFINE_LOGGER;

   bool cmdParseStatus = true;
   for (int arg = 1; arg < argc; arg++) {
      int argsLeft = argc - arg - 1;
      if (!_stricmp(argv[arg], "-appBlastAcceptHttpsMode")) {
         opt.SetAppBlastAcceptHttpsMode(true);
      } else if (!_stricmp(argv[arg], "-browserAllowFile")) {
         opt.SetBrowserAllowFile(true);
      } else if (!_stricmp(argv[arg], "-browserPath")) {
         if (argsLeft >= 1) {
            opt.SetBrowserPath(argv[arg + 1]);
            arg++;
         } else {
            LOG_ERROR(LOG, "Need to specify path for -browserPath.");
            cmdParseStatus = false;
            break;
         }
      } else if (!_stricmp(argv[arg], "-clientPath")) {
         if (argsLeft >= 1) {
            opt.SetClientPath(argv[arg + 1]);
            arg++;
         } else {
            LOG_ERROR(LOG, "Need to specify path for -clientPath.");
            cmdParseStatus = false;
            break;
         }
      } else if (!_stricmp(argv[arg], "-help")) {
         PrintUsage();
         exit(0);
      } else if (!_stricmp(argv[arg], "-nonsecureBlastConnection")) {
         opt.SetSecureBlastConnection(false);
      } else if (!_stricmp(argv[arg], "-nonsecureBrowserMode")) {
         opt.SetSecureBrowserMode(false);
      } else if (!_stricmp(argv[arg], "-skipBrowserExit")) {
         opt.SetBrowserExit(false);
      } else if (!_stricmp(argv[arg], "-skipTestCases")) {
         if (argsLeft >= 1) {
            std::list<std::string> skipTestCases;
            std::istringstream in(argv[arg + 1]);
            std::string tc;
            while (std::getline(in, tc, ',')) {
               skipTestCases.insert(skipTestCases.end(), tc);
            }
            opt.SetSkipTestCases(skipTestCases);
            arg++;
         } else {
            LOG_ERROR(LOG, "Need to specify test cases for -skipTestCases.");
            cmdParseStatus = false;
            break;
         }
      } else if (!_stricmp(argv[arg], "-testCases")) {
         if (argsLeft >= 1) {
            std::list<std::string> testCases;
            std::istringstream in(argv[arg + 1]);
            std::string tc;
            while (std::getline(in, tc, ',')) {
               testCases.insert(testCases.end(), tc);
            }
            opt.SetTestCases(testCases);
            arg++;
         } else {
            LOG_ERROR(LOG, "Need to specify test cases for -testCases.");
            cmdParseStatus = false;
            break;
         }
      } else if (!_stricmp(argv[arg], "-testFiles")) {
         if (argsLeft >= 1) {
            std::list<std::string> testFiles;
            std::istringstream in(argv[arg + 1]);
            std::string tf;
            while (std::getline(in, tf, ',')) {
               testFiles.insert(testFiles.end(), tf);
            }
            opt.SetTestFiles(testFiles);
            arg++;
         } else {
            LOG_ERROR(LOG, "Need to specify filename for -testFiles.");
            cmdParseStatus = false;
            break;
         }
      } else {
         LOG_ERROR(LOG, "Unknown program option: %s.", argv[arg]);
         cmdParseStatus = false;
         break;
      }
   }
   if (!cmdParseStatus) {
      PrintUsage();
      return false;
   }

   return true;
}


/*
 *----------------------------------------------------------------------------
 *
 * PrintUsage --
 *
 *    Print usage information.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

void
PrintUsage() {
   char *usage =
      "\n"
      "bitb [options]\n"
      "where options are:\n"
      "-appBlastAcceptHttpsMode\n"
      "   Put appblast in accepting https connection mode. This is used to only\n"
      "   enable browser to connect, which then give user a chance to manually\n"
      "   accept self-signed certificate.\n"
      "   This is a one-time setup (until the certificate change again).\n"
      "   Without accepting the certificate manually, connect step in the test\n"
      "   will fail when the connection to appblast is in secure mode (which is\n"
      "   the default).\n"
      "-browserAllowFile (opt)\n"
      "   Add --allow-file-access-from-files option when starting chrome.\n"
      "-browserPath <browser path executable> (req)\n"
      "   Specify the path to browser, BitB will start as (blast) client.\n"
      "   (Default:'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', or\n"
      "   (        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'\n"
      "-clientPath <client path> (opt)\n"
      "   Specify the mock client (html) file. The mock Client implementation.\n"
      "   (Default: '..\\..\\mockClient\\test.html' relative to BitB).\n"
      "-help (opt)\n"
      "   Print this usage documentation.\n"
      "-nonsecureBlastConnection (opt)\n"
      "   Instruct client to use non-SSL when connecting to Blast.\n"
      "-nonsecureBrowserMode (opt)\n"
      "   Instruct BitB to start browser/client in non secure mode.\n"
      "-skipBrowserExit (opt)\n"
      "   BitB will skip exiting the browser/client.\n"
      "-skipTestCases <comma-separated list of test cases> (opt)\n"
      "   Instruct BitB only to skip running the listed test case from the\n"
      "   test file. (Default:none).\n"
      "   This option can't be used together with -testCase option.\n"
      "-testCases <comma-separated list of test cases> (opt)\n"
      "   Instruct BitB only to run the listed test case from the\n"
      "   test file. (Default:run all).\n"
      "   This option can't be used together with -skipTestCase option.\n"
      "-testFiles <comma-separated list of json test file paths> (opt)\n"
      "   Specify the test files to use. The test file contain the list of\n"
      "   test cases to run.\n"
      "   (Default: '..\\..\\testCases\\stableTestCases.json' relative to BitB).\n"
      "\n";

   printf("%s", usage);
}



/*
 *----------------------------------------------------------------------------
 *
 * ExtractBrowserLog --
 *
 *    Copy the (chrome) browser log to bitb's log directory, and name it using
 *    browser_<date>_<time>_<truncated-testname>.log format
 *
 * Results:
 *    None
 *
 * Side effects:
 *    Copy (chrome) browser into bitb's log directory.
 *
 *----------------------------------------------------------------------------
 */

void
ExtractBrowserLog(BitBOption &bitBOption,    // IN
                  std::string testName)      // IN
{
   if (!bitBOption.GetBrowserLogPath().empty()) {
      DEFINE_LOGGER;
      std::wstring testNameW(testName.begin(), testName.end());

      std::wstring oldName = bitBOption.GetBrowserLogPath();
      std::wstring newName = bitBOption.GetBitBLogDir() +
                             L"\\browser_" + GetTimeStringW() + L"_" +
                             testNameW.substr(0, 20) + L".log";
      if (!CopyFileW(oldName.c_str(), newName.c_str(), true)) {
         LOG_WARN(LOG, "Unable to copy from:%ls to:%ls. Error:0x%08lx.",
                  oldName.c_str(), newName.c_str(), GetLastError());
      } else {
         LOG_DEBUG(LOG, "Copying chrome log file from:%ls to:%ls.",
                   oldName.c_str(), newName.c_str());
      }
   }
}


/*
 *----------------------------------------------------------------------------
 *
 * GetTimeStringW --
 *
 *    Get local time as string, in the format as HHMMSSmmm.
 *
 * Results:
 *    formatted time string.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::wstring
GetTimeStringW()
{
   SYSTEMTIME st;
   GetLocalTime(&st);

   std::wostringstream oss;
   oss << std::setfill(L'0') << std::setw(4) << st.wYear
      << std::setfill(L'0') << std::setw(2) << st.wMonth
      << std::setfill(L'0') << std::setw(2) << st.wDay
      << L'_'
      << std::setfill(L'0') << std::setw(2) << st.wHour
      << std::setfill(L'0') << std::setw(2) << st.wMinute
      << std::setfill(L'0') << std::setw(2) << st.wSecond
      << std::setfill(L'0') << std::setw(3) << st.wMilliseconds;
   return std::wstring(oss.str());
}


/*
 *----------------------------------------------------------------------------
 *
 * VerifyBlastConfig --
 *
 *    Verify that Blast configuration is compatible with BitB.
 *
 * Results:
 *    true on success or false on failure.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
VerifyBlastConfig()
{
   DEFINE_LOGGER;

   // load blast's config setting
   PersistentConfig *blastConfig = PersistentConfig::NewUserAppInstance();
   blastConfig->Reload(false);

   // Also read bora preferences from registry
   Preference_InitFromPersistentConfig(blastConfig);

   bool isBlankScreenEnabled;
   blastConfig->GetBool(CONFIG_BLANK_SCREEN_ENABLED, isBlankScreenEnabled);
   if (isBlankScreenEnabled) {
      LOG_ERROR(LOG, "BlankScreenEnabled regkey is enabled.");
      return false;
   } else {
      LOG_DEBUG(LOG, "BlankScreenEnabled regkey is disabled.");
   }

   return true;
}