/* **********************************************************
 * Copyright (C) 2016-2017 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

/*
 * TestCase.cpp --
 *
 *    Describe a test case, which can contain multiple actions.
 */

#include <algorithm>
#include <set>
#include <Shlobj.h>
#include <Shlwapi.h>
#include <vector>

#include "BitBOption.h"
#include "BitBUtil.h"

 // appblast/common
#include "appBlastUtil.h"


static std::wstring DEFAULT_BLAST_DMP_DIR =
   L"c:\\ProgramData\\VMware\\VMware Blast";


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::BitBOption --
 *
 *    Constructor.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

BitBOption::BitBOption()
   : mLog(log4cxx::Logger::getLogger("BitBOption")),
     mAppBlastAcceptHttpsMode(false),
     mBrowserAllowFile(false),
     mBrowserExit(true),
     mBrowserPath(""),
     mClientPath(""),
     mSecureBlastConnection(true),
     mSecureBrowserMode(true)
{
   mTestFiles.push_back(GetCurrentBinaryPath() +
                        "\\testCases\\stableTestCases.json");
   if (!AbUtil::GetCommonAppDataDir(mBlastDumpDir)) {
      mBlastDumpDir = DEFAULT_BLAST_DMP_DIR;
      LOG_WARN(mLog, "Unable to retrieve blast dump directory setting. "
               "Using default:%ls.", mBlastDumpDir.c_str());
   }
   // Currently, blast's dump/log, bitb's dump/log are kept on same location.
   mBitBLogDir = mBlastDumpDir;

   WCHAR szPath[MAX_PATH];
   HRESULT res = SHGetFolderPathW(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, szPath);
   if (SUCCEEDED(res)) {
      mBrowserLogPath = std::wstring(szPath) + L"\\Google\\Chrome\\" +
                        L"User Data\\chrome_debug.log";
   } else {
      LOG_WARN(mLog, "Unable to retrieve CSIDL_LOCAL_APPDATA. Error:0x%08lx.",
               res);
   }

   std::string temp = GetCurrentBinaryPath() + "\\mockClient\\mockClient.html";
   if (PathFileExistsA(temp.c_str())) {
      mClientPath = temp;
   }

   temp = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe";
   if (PathFileExistsA(temp.c_str())) {
      mBrowserPath = temp;
   } else {
      temp = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
      if (PathFileExistsA(temp.c_str())) {
         mBrowserPath = temp;
      }
   }
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::~BitBOption --
 *
 *    Destructor.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

BitBOption::~BitBOption()
{
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::IsAppBlastAcceptHttpsMode --
 * BitBOption::SetAppBlastAcceptHttpsMode --
 *
 *    Getter/Setter for "-appBlastAcceptHttpsMode" flag.
 *    This flag will put appblast into a "listening" mode, such that browser
 *    can https-connect to appblast, to accept the self-signed cerificate.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
BitBOption::IsAppBlastAcceptHttpsMode()
{
   return mAppBlastAcceptHttpsMode;
}

void
BitBOption::SetAppBlastAcceptHttpsMode(bool acceptHttpsMode)
{
   mAppBlastAcceptHttpsMode = acceptHttpsMode;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::IsBrowserAllowFile --
 * BitBOption::SetBrowserAllowFile --
 *
 *    Getter/Setter for "--allow-file-access-from-files" flag.
 *    This is a workaround issue in wmks when used with "h264multimon" option
 *    enabled against a vm/desktop with vgpu.
 *    The issue will cause the following error:
 *       "Not allowed to load local resource: blob:null/<some_guid>"
 *    It is happening in MP4Decoder.prototype.reset(), when performing:
 *       this._mediaPlayer.src = "";
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
BitBOption::IsBrowserAllowFile()
{
   return mBrowserAllowFile;
}

void
BitBOption::SetBrowserAllowFile(bool browerAllowFile)
{
   mBrowserAllowFile = browerAllowFile;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::IsBrowserExit --
 * BitBOption::SetBrowserExit --
 *
 *    Getter/Setter for browserExit flag, specifying whether BitB will exit
 *    client (browser) when it completes running testcase.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
BitBOption::IsBrowserExit()
{
   return mBrowserExit;
}

void
BitBOption::SetBrowserExit(bool browerExit)
{
   mBrowserExit = browerExit;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetBrowserLogPath --
 *
 *    Getter for browser (console) file name path.
 *
 * Results:
 *    directory location.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

// TODO: When needed, implement SetBrowserLogPath() and command line interface.
std::wstring
BitBOption::GetBrowserLogPath()
{
   return mBrowserLogPath;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetBrowserPath --
 * BitBOption::SetBrowserPath --
 *
 *    Getter/Setter for browser path.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::string
BitBOption::GetBrowserPath()
{
   return mBrowserPath;
}

void
BitBOption::SetBrowserPath(std::string browserPath)
{
   mBrowserPath = browserPath;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetClientPath --
 * BitBOption::SetClientPath --
 *
 *    Getter/Setter for mock client path.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::string
BitBOption::GetClientPath()
{
   return mClientPath;
}

void
BitBOption::SetClientPath(std::string clientPath)
{
   mClientPath = clientPath;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::IsSecureBlastConnection --
 * BitBOption::SetSecureBlastConnection --
 *
 *    Getter/Setter for secure blast connection flag.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
BitBOption::IsSecureBlastConnection()
{
   return mSecureBlastConnection;
}

void
BitBOption::SetSecureBlastConnection(bool secureBlastConnection)
{
   mSecureBlastConnection = secureBlastConnection;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::IsSecureBrowserMode --
 * BitBOption::SetSecureBrowserMode --
 *
 *    Getter/Setter for secure browser mode flag - whether browser is running
 *    in secure or otherwise.
 *    This is mainly used for chrome, when BitB is running inside psExec.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
BitBOption::IsSecureBrowserMode()
{
   return mSecureBrowserMode;
}

void
BitBOption::SetSecureBrowserMode(bool secureBrowserMode)
{
   mSecureBrowserMode = secureBrowserMode;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetTestFile --
 * BitBOption::SetTestFile --
 *
 *    Getter/Setter for test files.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::list<std::string>
BitBOption::GetTestFiles()
{
   return mTestFiles;
}

void
BitBOption::SetTestFiles(std::list<std::string> &testFiles)
{
   mTestFiles = testFiles;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetTestFileName --
 *
 *    Get test file name (without file path).
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::string
BitBOption::GetTestFileName(std::string testFileWithPath)      // IN
{
   std::vector<std::string> result;
   std::set<char> delimiters;
   delimiters.insert('\\');
   delimiters.insert('.');

   char const* testFile = testFileWithPath.c_str();
   char const* start = testFile;
   for (; *testFile; ++testFile) {
      if (delimiters.find(*testFile) != delimiters.end()) {
         if (start != testFile) {
            std::string str(start, testFile);
            result.push_back(str);
         } else {
            result.push_back("");
         }
         start = testFile + 1;
      }
   }
   result.push_back(start);

   if (result.back() == "json") {
      result.pop_back();
   }

   return result.back();
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetBitBLogDir --
 *
 *    Getter/Setter for BitB's application log directory.
 *
 * Results:
 *    BitB app log directory.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

// TODO: When needed, implement SetBitBLogDir() and command line interface.
std::wstring
BitBOption::GetBitBLogDir()
{
   return mBitBLogDir;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetBlastDumpDir --
 *
 *    Getter/Setter for Blast dump directory.
 *
 * Results:
 *    Blast dump directory.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

// TODO: When needed, implement SetBlastDumpDir() and command line interface.
std::wstring
BitBOption::GetBlastDumpDir()
{
   return mBlastDumpDir;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::IsInTestCases --
 *
 *    Check whether testCase is in the testcases list, requested to be run.
 *
 * Results:
 *    true if in the list, false otherwise.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
BitBOption::IsInTestCases(std::string testCase) // IN
{
   if (mTestCases.empty()) {
      return false;
   } else {
      std::list<std::string>::iterator found = std::find(mTestCases.begin(),
                                                         mTestCases.end(),
                                                         testCase);
      if (mTestCases.end() == found) {
         return false;
      } else {
         return true;
      }
   }
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetCommaSeparatedList --
 *
 *    Get comma-separated string of all elements in string list.
 *
 * Results:
 *    comma-separated list.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::string
BitBOption::GetCommaSeparatedList(std::list<std::string> stringList)
{
   if (stringList.empty()) {
      return "";
   } else {
      std::ostringstream oss;
      std::list<std::string>::iterator ndLastEntry = stringList.end();
      --ndLastEntry;
      std::copy(stringList.begin(), ndLastEntry,
                std::ostream_iterator<std::string>(oss, ","));
      oss << stringList.back();
      return oss.str();
   }
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::SetTestCases --
 *
 *    Setter for test file.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

void
BitBOption::SetTestCases(std::list<std::string> &testCases) // IN
{
   mTestCases = testCases;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::IsInSkipTestCases --
 * BitBOption::SetSkipTestCases --
 *
 *    Check whether testCase is in the skip testcases list, to be skipped.
 *    Setter for skip test cases.
 *
 * Results:
 *    True if in the list, False otherwise.
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
BitBOption::IsInSkipTestCases(std::string testCase)
{
   if (mSkipTestCases.empty()) {
      return false;
   } else {
      std::list<std::string>::iterator found = std::find(mSkipTestCases.begin(),
                                                         mSkipTestCases.end(),
                                                         testCase);
      if (mSkipTestCases.end() == found) {
         return false;
      } else {
         return true;
      }
   }
}

void
BitBOption::SetSkipTestCases(std::list<std::string> &skipTestCases)
{
   mSkipTestCases = skipTestCases;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetCommandLinePath --
 *
 *    If filePath has space, surround it with double quotes if it doesn't
 *    already have.
 *
 * Results:
 *    filePath surrounded with double quotes if it has space in it.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::string
BitBOption::GetCommandLinePath(const std::string &filePath)    // IN
{
   // TODO: trimming, handle non-space character space (locale independent).
   if (std::string::npos != filePath.find(' ') &&
       !(filePath.find('\"') == 0 &&
         filePath.rfind('\"') == filePath.length() - 1)) {
         return std::string("\"") + filePath + std::string("\"");
   }
   return filePath;
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetBrowserCmdLine --
 *
 *    Retrieve command line to start browser
 *
 * Results:
 *    Command line to start browser.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::string
BitBOption::GetBrowserCmdLine(unsigned int clientIndex)     // IN
{
   if (!GetBrowserPath().empty() && !GetClientPath().empty()) {
      std::string cmdLine = GetCommandLinePath(GetBrowserPath())
         + " --enable-logging --v=1"
         + (IsSecureBrowserMode() ? "" : " --no-sandbox")
         + (IsBrowserAllowFile() ? " --allow-file-access-from-files" : "")
         + " " + GetCommandLinePath(GetClientPath());
      cmdLine += clientIndex == PRIMARY_CLIENT_INDEX ? "" : " -incognito";

      return cmdLine;
   }
   return "";
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::GetCurrentBinaryPath --
 *
 *    Returns the directory of the currently running executable.
 *
 * Results:
 *    Current directory path.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

std::string
BitBOption::GetCurrentBinaryPath() {
   wchar_t buffer[MAX_PATH];
   GetModuleFileName(NULL, buffer, MAX_PATH);

   std::wstring ws(buffer);
   std::string bufferStr(ws.begin(), ws.end());
   std::string::size_type pos = bufferStr.find_last_of("\\/");
   return bufferStr.substr(0, pos);
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::LogOptions --
 *
 *    Log the options into log file.
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    The selection options is appended into log file.
 *
 *----------------------------------------------------------------------------
 */

void
BitBOption::LogOptions()
{
   LOG_INFO(mLog, "BitB Options:");
   LOG_INFO(mLog, "- BitB Log Dir     : %ls", mBitBLogDir.c_str());
   LOG_INFO(mLog, "- Blast Dump Dir   : %ls", mBlastDumpDir.c_str());
   LOG_INFO(mLog, "- BrowserAllowFile : %s",
      mBrowserAllowFile ? "True" : "False");
   LOG_INFO(mLog, "- BrowserExit      : %s", mBrowserExit ? "True" : "False");
   LOG_INFO(mLog, "- BrowserLogPath   : %ls",
            GetBrowserLogPath().c_str());
   LOG_INFO(mLog, "- BrowserPath      : %s",
            mBrowserPath.empty() ? "<empty>" : mBrowserPath.c_str());
   LOG_INFO(mLog, "- ClientPath       : %s",
            mClientPath.empty() ? "<empty>" : mClientPath.c_str());
   LOG_INFO(mLog, "- SecureBlastConn  : %s",
            mSecureBlastConnection ? "True" : "False");
   LOG_INFO(mLog, "- SecureBrowserMode: %s",
            mSecureBrowserMode ? "True" : "False");
   std::string testCases = GetCommaSeparatedList(mTestCases);
   LOG_INFO(mLog, "- TestCases        : %s",
            testCases.empty() ? "all" : testCases.c_str());
   std::string testFiles = GetCommaSeparatedList(mTestFiles);
   LOG_INFO(mLog, "- TestFiles        : %s",
            testFiles.empty() ? "<empty>" : testFiles.c_str());
}


/*
 *----------------------------------------------------------------------------
 *
 * BitBOption::Validate --
 *
 *    Validate the options
 *
 * Results:
 *    None.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
BitBOption::Validate()
{
   if (mBrowserPath.empty() || mClientPath.empty()) {
      LOG_ERROR(mLog, "Both Browser and Client Path have to be defined.");
      return false;
   }
   if (!PathFileExistsA(mBrowserPath.c_str())) {
      LOG_ERROR(mLog, "BrowserPath:%s does not exist. Error:0x%08lx.",
                mBrowserPath.c_str(), GetLastError());
      return false;
   }
   if (!PathFileExistsA(mClientPath.c_str())) {
      LOG_ERROR(mLog, "ClientPath:%s does not exist. Error:0x%08lx.",
                mClientPath.c_str(), GetLastError());
      return false;
   }
   if (!mTestCases.empty() && !mSkipTestCases.empty()) {
      LOG_ERROR(mLog, "Only one of testCases or skipTestCase list can be "
                "defined.");
      return false;
   }

   return true;
}


/*
 *----------------------------------------------------------------------------
 *
 * TestCase::IsTestCaseIncludedToRun --
 *
 *    Check if the test case is included/schedule to run.
 *
 * Results:
 *    true/false.
 *
 * Side effects:
 *    None.
 *
 *----------------------------------------------------------------------------
 */

bool
BitBOption::IsTestCaseIncludedToRun(std::string testCase)
{
   if (IsInSkipTestCases(testCase)) {
      return false;
   }
   // Empty mTestCases implies running everything
   return (mTestCases.empty() || IsInTestCases(testCase));
}