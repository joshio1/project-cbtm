/* **********************************************************
 * Copyright (C) 2016-2017 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

/*
 * SessionData.h --
 *
 *    Session data structure used by BitB - Controller.
 */

#pragma once

#include <list>
#include <string>

#include "Logging.h"

class BitBOption {
public:
   BitBOption();
   virtual ~BitBOption();

   bool IsAppBlastAcceptHttpsMode();
   void SetAppBlastAcceptHttpsMode(bool acceptHttpsMode);
   std::wstring GetBitBLogDir();
   std::wstring GetBlastDumpDir();
   bool IsBrowserAllowFile();
   void SetBrowserAllowFile(bool browserAllowFile);
   bool IsBrowserExit();
   void SetBrowserExit(bool browserExit);
   std::wstring GetBrowserLogPath();
   std::string GetBrowserPath();
   void SetBrowserPath(std::string browserPath);
   std::string GetClientPath();
   void SetClientPath(std::string clientPath);
   bool IsSecureBlastConnection();
   void SetSecureBlastConnection(bool secureBlastConnection);
   bool IsSecureBrowserMode();
   void SetSecureBrowserMode(bool secureBrowserMode);
   void SetTestFiles(std::list<std::string> &testFiles);
   std::list<std::string> GetTestFiles();
   std::string GetTestFileName(std::string testFileWithPath);
   void SetTestCases(std::list<std::string> &testCases);
   void SetSkipTestCases(std::list<std::string> &skipTestCases);

   bool IsTestCaseIncludedToRun(std::string testCase);

   std::string GetBrowserCmdLine(unsigned int clientIndex);
   void LogOptions();
   bool Validate();

protected:
   std::string GetCurrentBinaryPath();
   std::string GetCommaSeparatedList(std::list<std::string> stringList);
   std::string GetCommandLinePath(const std::string &filePath);
   bool IsInTestCases(std::string testCase);
   bool IsInSkipTestCases(std::string testCase);

   log4cxx::LoggerPtr mLog;

   bool mAppBlastAcceptHttpsMode;
   std::wstring mBitBLogDir;
   std::wstring mBlastDumpDir;
   bool mBrowserAllowFile;
   bool mBrowserExit;
   std::wstring mBrowserLogPath;
   std::string mBrowserPath;
   std::string mClientPath;
   bool mSecureBlastConnection;
   bool mSecureBrowserMode;
   std::list<std::string> mSkipTestCases;
   std::list<std::string> mTestCases;
   std::list<std::string> mTestFiles;
};