/* **********************************************************
 * Copyright (C) 2017 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

/*
 * BitBUtil.h --
 *
 *    BitB utility functions.
 */

#pragma once

#include <sstream>
#include <string>


static const unsigned int PRIMARY_CLIENT_INDEX = 0;

namespace BitBUtil
{
   template <typename T>
   std::string to_string(T value)
   {
      std::ostringstream os;
      os << value;
      return os.str();
   }
}